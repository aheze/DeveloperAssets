struct EmojiItem: Identifiable, Codable, Hashable {
    let id: Int
    
    /// The categories that this emoji item belongs to, e.g. "A"
    /// TODO: Should rename to `emojiCategories` or something
    let emoji: [String]
    
    /// The name of this emoji
    let name: String
    
    /// The description of this emoji
    let description: String
}

/// A category of emoji
struct EmojiCategory: Identifiable {
    
    /// for `Identifiable`
    var id: String {
        return letter
    }
    
    /// Shown as the section title
    var letter: String
    
    /// The emoji that belong to this category
    var emoji: [EmojiItem]
}
