import SwiftUI

@main
struct MyApp: App {
    @StateObject var emo = Emote()
    var body: some Scene {
        WindowGroup {
            ContentView().environmentObject(emo)
        }
    }
}
