import SwiftUI

struct MyView: View {
    var body: some View {
        List{
            Section("A"){
                Text("Alien Monster A B")
                Text("Pizza P A S T")
                Text("Puzzle Piece P W A U")
                Text("World Map")
            }
            Section("B"){
                Text("Alien Monster A B")
                Text("Rocket R B P")
                Text("Teddy Bear T B C")
            }
            Section("C"){
                Text("Avocado C D E N")
                Text("Teddy Bear T B C")
            }
            Section("D"){
                Text("Avocado C D E N")
            }
            Section("E"){
                Text("Avocado C D E N")
            }
            Section("F"){
                Text("French Fries F T G S")
                Text("Unicorn U T F")
            }
            Section("N"){
                Text("Avocado C D E N")
            }
            Section("P"){
                Text("Pizza P A S T")
                Text("Puzzle Piece P W A U")
                Text("Rocket R B P")
            }
        }.listStyle(.plain)
    }
}

struct MyView_Previews: PreviewProvider {
    static var previews: some View {
        MyView()
    }
}
