import Foundation

class Emote: ObservableObject{
    @Published var emojiList: [EmojiItem] = []
    @Published var emojiCategories: [EmojiCategory] = []
    
    
    init(){
        loadData()
    }

    func loadData() {
        guard let url = Bundle.main.url(forResource: "EmojiList", withExtension: "json")
        else {
            print("JSON file not found")
            return
        }
        
        guard let data = try? Data(contentsOf: url) else {
            print("Couldnt retrieve data")
            return
        }
        guard let emojiDecode = try? JSONDecoder().decode([EmojiItem].self, from: data) else {
            print("Couldnt decode Json")
            return
        }
        self.emojiList = emojiDecode
        
        
        /// Sort the emoji into categories
        var emojiCategories = [EmojiCategory]()
        for emojiItem in emojiList {
            
            /// Loop through each category that the emojiItem belongs to
            for emojiCategoryLetter in emojiItem.emoji {
            
                
                /// Check if `emojiCategories` contains a category that matches this category (emojiCategoryLetter)
                if let existingCategoryIndex = emojiCategories.firstIndex(where: { $0.letter == emojiCategoryLetter }) {
                    
                    /// If true, append this emojiItem to the parent category's emoji itmes.
                    emojiCategories[existingCategoryIndex].emoji.append(emojiItem)
                } else {
                    
                    /// Otherwise, create a new category and append it.
                    let newCategory = EmojiCategory(letter: emojiCategoryLetter, emoji: [emojiItem])
                    emojiCategories.append(newCategory)
                }
                
            }
        }
        
        /// Set the categories for displaying in the List.
        self.emojiCategories = emojiCategories
        
    }
}


