
import SwiftUI
//the names have all the letters that it should appear under in categories 
//example Alien Monster the emoji field has an array of ["A", "B"] so i named it "Alien Monster A B"

// checkout WhatImTryingToAchieve to see a hardcoded example of what I want
struct ContentView: View {
    
    @EnvironmentObject var emo: Emote
    var body: some View {
        NavigationView {
            List{
                ForEach(emo.emojiCategories) { emojiCategory in
                    
                    Section(emojiCategory.letter) {
                    //Uncomment the commented parts to see a foreach with section headers
                        ForEach(emojiCategory.emoji, id: \.self) { emojiItem in
                    
                            NavigationLink(destination: DetailsView(emojiItem: emojiItem)) {
                                HStack {
                                    Text(emojiItem.name)
                                }
                            }
                        }
                    }
                }
            }.listStyle(.plain)
                .navigationBarTitle("Emoji")
        }
    }
}

