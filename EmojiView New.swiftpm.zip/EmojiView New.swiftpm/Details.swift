import SwiftUI

struct DetailsView: View {
    @EnvironmentObject var emo: Emote
    let emojiItem: EmojiItem
    var body: some View {
        VStack(alignment: .leading) {
            Spacer()
            Text(emojiItem.description)
            Spacer()
        }
        .navigationBarTitle(emojiItem.name, displayMode: .inline)
    }
}



