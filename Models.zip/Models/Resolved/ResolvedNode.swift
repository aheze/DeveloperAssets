//
//  ResolvedNode.swift
//  MetalMathTest
//  
//  Created by Andrew Zheng (github.com/aheze) on 4/9/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

public enum ResolvedNode {
    case resolvedNumber(ResolvedNumber)
    case resolvedMatrix(ResolvedMatrix)
    case resolvedOperator(ResolvedOperator)
    case resolvedFunction(ResolvedFunction)
    case resolvedVariable(ResolvedVariable)
}
