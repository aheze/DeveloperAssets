//
//  Function.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 4/9/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

public typealias ResolvedNumber = Double

public struct ResolvedMatrix {
    public var rowsCount: Int
    public var colsCount: Int

    public var resolvedFields: [ResolvedNodeField]
}

public enum ResolvedOperator {
    case divide
    case multiply
    case subtract
    case add

    // prefix operator
    case negate
}

public struct ResolvedFunction {
    public var kind: Kind
    public var resolvedFields: [ResolvedNodeField]

    public enum Kind: Codable, Equatable, Hashable {
        // MARK: Basic functions

        case sqrt
        case nroot
        case ln
        case log
        case loga
        case abs
        case floor
        case ceil
        case round
        case sign
        case mod
        case inverse

        // MARK: Probability

        case npr
        case ncr

        // MARK: Advanced

        case numericalDifferentiation
        case numericalIntegration
        case summation // sigma
        case product // capital pi

        // MARK: Trig functions

        case sin
        case cos
        case tan
        case sin2
        case cos2
        case tan2
        case asin
        case acos
        case atan

        case csc
        case sec
        case cot
        case csc2
        case sec2
        case cot2
        case acsc
        case asec
        case acot

        // MARK: Hyperbolic trig

        case sinh
        case cosh
        case tanh
        case sinh2
        case cosh2
        case tanh2
        case asinh
        case acosh
        case atanh

        case csch
        case sech
        case coth
        case csch2
        case sech2
        case coth2
        case acsch
        case asech
        case acoth

        // MARK: Matrices

        case matrixRREF
        case matrixDeterminant
        case matrixTrace
        case matrixTranspose

        // MARK: - Resolved symbols

        case power
        case enterExponent
        case percent
        case factorial
        case negate

        public var title: String {
            Kind.kindToString[self] ?? "Unknown"
        }

        // MARK: - Strings

        public static var sqrtString = "sqrt"
        public static var nrootString = "nroot"
        public static var lnString = "ln"
        public static var logString = "log"
        public static var logaString = "loga"
        public static var absString = "abs"
        public static var floorString = "floor"
        public static var ceilString = "ceil"
        public static var roundString = "round"
        public static var signString = "sign"
        public static var modString = "mod"
        public static var inverseString = "inverse"
        public static var nprString = "npr"
        public static var ncrString = "ncr"
        public static var numericalDifferentiationString = "numericalDifferentiation"
        public static var numericalIntegrationString = "numericalIntegration"
        public static var summationString = "summation"
        public static var productString = "product"
        public static var sinString = "sin"
        public static var cosString = "cos"
        public static var tanString = "tan"
        public static var sin2String = "sin2"
        public static var cos2String = "cos2"
        public static var tan2String = "tan2"
        public static var asinString = "asin"
        public static var acosString = "acos"
        public static var atanString = "atan"
        public static var cscString = "csc"
        public static var secString = "sec"
        public static var cotString = "cot"
        public static var csc2String = "csc2"
        public static var sec2String = "sec2"
        public static var cot2String = "cot2"
        public static var acscString = "acsc"
        public static var asecString = "asec"
        public static var acotString = "acot"
        public static var sinhString = "sinh"
        public static var coshString = "cosh"
        public static var tanhString = "tanh"
        public static var sinh2String = "sinh2"
        public static var cosh2String = "cosh2"
        public static var tanh2String = "tanh2"
        public static var asinhString = "asinh"
        public static var acoshString = "acosh"
        public static var atanhString = "atanh"
        public static var cschString = "csch"
        public static var sechString = "sech"
        public static var cothString = "coth"
        public static var csch2String = "csch2"
        public static var sech2String = "sech2"
        public static var coth2String = "coth2"
        public static var acschString = "acsch"
        public static var asechString = "asech"
        public static var acothString = "acoth"
        public static var matrixRREFString = "rref"
        public static var matrixDeterminantString = "det"
        public static var matrixTraceString = "trace"
        public static var matrixTransposeString = "transpose"
        public static var powerString = "power"
        public static var enterExponentString = "ee"
        public static var percentString = "percent"
        public static var factorialString = "factorial"
        public static var negateString = "negate"

        public static var kindToString: [Kind: String] = [
            .sqrt: sqrtString,
            .nroot: nrootString,
            .ln: lnString,
            .log: logString,
            .loga: logaString,
            .abs: absString,
            .floor: floorString,
            .ceil: ceilString,
            .round: roundString,
            .sign: signString,
            .mod: modString,
            .inverse: inverseString,
            .npr: nprString,
            .ncr: ncrString,
            .numericalDifferentiation: numericalDifferentiationString,
            .numericalIntegration: numericalIntegrationString,
            .summation: summationString,
            .product: productString,
            .sin: sinString,
            .cos: cosString,
            .tan: tanString,
            .sin2: sin2String,
            .cos2: cos2String,
            .tan2: tan2String,
            .asin: asinString,
            .acos: acosString,
            .atan: atanString,
            .csc: cscString,
            .sec: secString,
            .cot: cotString,
            .csc2: csc2String,
            .sec2: sec2String,
            .cot2: cot2String,
            .acsc: acscString,
            .asec: asecString,
            .acot: acotString,
            .sinh: sinhString,
            .cosh: coshString,
            .tanh: tanhString,
            .sinh2: sinh2String,
            .cosh2: cosh2String,
            .tanh2: tanh2String,
            .asinh: asinhString,
            .acosh: acoshString,
            .atanh: atanhString,
            .csch: cschString,
            .sech: sechString,
            .coth: cothString,
            .csch2: csch2String,
            .sech2: sech2String,
            .coth2: coth2String,
            .acsch: acschString,
            .asech: asechString,
            .acoth: acothString,
            .matrixRREF: matrixRREFString,
            .matrixDeterminant: matrixDeterminantString,
            .matrixTrace: matrixTraceString,
            .matrixTranspose: matrixTransposeString,
            .power: powerString,
            .enterExponent: enterExponentString,
            .percent: percentString,
            .factorial: factorialString,
            .negate: negateString,
        ]
    }
}

public typealias ResolvedVariable = String
