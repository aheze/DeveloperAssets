////
////  NodeField+EvaluateToMatrix.swift
////  MetalMathTest
////  
////  Created by Andrew Zheng (github.com/aheze) on 3/28/24.
////  Copyright © 2024 Andrew Zheng. All rights reserved.
////
//
//import Foundation
//
//extension NodeField {
//    func evaluateToMatrix(context: EvaluateContext) throws -> Matrix {
//        // TODO!
//        // Must account for addition, subtraction, division, and multiplication.
////        return try nodes.map { try $0.evaluateToMatrix(context: context) }
//        
//        // MARK: TODO!!!
//        return try nodes.first?.evaluateToMatrix(context: context) ?? Matrix(rowsCount: 0, colsCount: 0, contents: [0])
//    }
//}
