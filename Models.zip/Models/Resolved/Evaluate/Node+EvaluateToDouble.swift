//
//  Node+EvaluateToNumber.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 3/24/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

extension Node {
    func evaluateChildFieldToDouble(index: Int, context: EvaluateContext) throws -> Double {
        let field = try getChildField(index: index)
        return try field.evaluateToDouble(context: context)
    }
}

extension Node {
    func evaluateToDouble(context: EvaluateContext) throws -> Double {
        switch symbol {
        case ._0:
            throw EvaluateError.unresolvedSymbol(symbol: symbol)
        case ._1:
            throw EvaluateError.unresolvedSymbol(symbol: symbol)
        case ._2:
            throw EvaluateError.unresolvedSymbol(symbol: symbol)
        case ._3:
            throw EvaluateError.unresolvedSymbol(symbol: symbol)
        case ._4:
            throw EvaluateError.unresolvedSymbol(symbol: symbol)
        case ._5:
            throw EvaluateError.unresolvedSymbol(symbol: symbol)
        case ._6:
            throw EvaluateError.unresolvedSymbol(symbol: symbol)
        case ._7:
            throw EvaluateError.unresolvedSymbol(symbol: symbol)
        case ._8:
            throw EvaluateError.unresolvedSymbol(symbol: symbol)
        case ._9:
            throw EvaluateError.unresolvedSymbol(symbol: symbol)
        case .period:
            throw EvaluateError.unresolvedSymbol(symbol: symbol)
        case .runtimeVariable(let variableContext):
            if let field = context.substitutions[variableContext.name] {
                return try field.evaluateToDouble(context: context)
            } else {
                throw EvaluateError.missingSubstitution(name: variableContext.name)
            }
        case .runtimeFunction(let functionContext):
            if let field = context.substitutions[functionContext.name] {
                var context = context

                // clear it first
                context.runtimeArgumentIndexToField = [:]

                // replace arguments with the actual fields
                for index in fields.indices {
                    context.runtimeArgumentIndexToField[index] = fields[index]
                }

                return try field.evaluateToDouble(context: context)
            } else {
                throw EvaluateError.missingSubstitution(name: functionContext.name)
            }
        case .runtimeArgument(let index):
            if let field = context.runtimeArgumentIndexToField[index] {
                return try field.evaluateToDouble(context: context)
            } else {
                throw EvaluateError.unresolvedArgument(index: index)
            }
        case .ambiguousDash:
            throw EvaluateError.unresolvedSymbol(symbol: symbol)
        case .ambiguousPercent:
            throw EvaluateError.unresolvedSymbol(symbol: symbol)
        case .ambiguousFactorial:
            throw EvaluateError.unresolvedSymbol(symbol: symbol)
        case .ambiguousEE:
            throw EvaluateError.unresolvedSymbol(symbol: symbol)
        case .ambiguousPowOperator:
            throw EvaluateError.unresolvedSymbol(symbol: symbol)
        case .ambiguousPowWithField:
            throw EvaluateError.unresolvedSymbol(symbol: symbol)
        case .simpleValue(let double):
            return double
        case .constant(let constant):
            return constant.value
        case .leftParenthesis:
            throw EvaluateError.attemptedToEvaluateParenthesis(symbol: symbol)
        case .rightParenthesis:
            throw EvaluateError.attemptedToEvaluateParenthesis(symbol: symbol)
        case .equals:
            throw EvaluateError.attemptedToEvaluateEquals
        case .comma:
            throw EvaluateError.attemptedToEvaluateComma
        case .fraction:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            let arg1 = try evaluateChildFieldToDouble(index: 1, context: context)
            return arg0 / arg1
        case .divide:
            throw EvaluateError.attemptedToEvaluateOperator(symbol: symbol) // divide should be handled in NodeField
        case .multiply:
            throw EvaluateError.attemptedToEvaluateOperator(symbol: symbol)
        case .add:
            throw EvaluateError.attemptedToEvaluateOperator(symbol: symbol)
        case .functionStem:
            throw EvaluateError.attemptedToEvaluateOperator(symbol: symbol)
        case .sqrt:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)

            // call the system `sqrt` function
            return sqrt(arg0)
        case .nroot:
            let n = try evaluateChildFieldToDouble(index: 0, context: context)
            let base = try evaluateChildFieldToDouble(index: 1, context: context)
            let power = Double(1) / n
            return pow(base, power)
        case .ln:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            return log(arg0)
        case .log:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            return log10(arg0)
        case .loga:
            let base = try evaluateChildFieldToDouble(index: 0, context: context)
            let value = try evaluateChildFieldToDouble(index: 1, context: context)
            return FunctionLibrary.logC(value: value, base: base)
        case .abs:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            return abs(arg0)
        case .floor:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            return floor(arg0)
        case .ceil:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            return ceil(arg0)
        case .round:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            return round(arg0)
        case .sign:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            return Double(FunctionLibrary.sign(value: arg0))
        case .mod:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            let arg1 = try evaluateChildFieldToDouble(index: 1, context: context)
            return fmod(arg0, arg1)
        case .inverse:
            // Note: inverse for matrices is handled in `simplify`
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            return Double(1) / arg0
        case .npr:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            let arg1 = try evaluateChildFieldToDouble(index: 1, context: context)
            return FunctionLibrary.npr(n: arg0, r: arg1)
        case .ncr:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            let arg1 = try evaluateChildFieldToDouble(index: 1, context: context)
            return FunctionLibrary.ncr(n: arg0, r: arg1)
        case .numericalDifferentiation:

            // MARK: - TODO

            return 0
        case .numericalIntegration:

            // MARK: - TODO

            return 0
        case .summation:
            let (lowerBound, upperBound, variableName) = try getArgumentsForAggregate(context: context)

            if lowerBound > upperBound {
                return 0
            }

            let sum = try FunctionLibrary.kahanSum(closedRange: lowerBound ... upperBound) { index in

                var context = context
                // e.g. n = 0
                context.substitutions[variableName] = NodeField(nodes: [Node(symbol: .simpleValue(Double(index)))])
                // e.g. 2n
                let value = try evaluateChildFieldToDouble(index: 2, context: context)
                return value
            }

            return sum
        case .product:
            let (lowerBound, upperBound, variableName) = try getArgumentsForAggregate(context: context)

            if lowerBound > upperBound {
                return 1
            }

            var product = Double(1)
            for index in lowerBound ... upperBound {
                // e.g. n = 0
                var context = context
                context.substitutions[variableName] = NodeField(nodes: [Node(symbol: .simpleValue(Double(index)))])

                // e.g. 2n
                let value = try evaluateChildFieldToDouble(index: 2, context: context)

                product *= value
            }

            return product
        case .sin:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            switch context.trigonometryMode {
            case .radian:
                return __sinpi(arg0 / .pi)
            case .degree:
                return __sinpi(arg0 / 180)
            }
        case .cos:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            switch context.trigonometryMode {
            case .radian:
                return __cospi(arg0 / .pi)
            case .degree:
                return __cospi(arg0 / 180)
            }
        case .tan:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            switch context.trigonometryMode {
            case .radian:
                return __tanpi(arg0 / .pi)
            case .degree:
                return __tanpi(arg0 / 180)
            }
        case .asin:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            switch context.trigonometryMode {
            case .radian:
                return asin(arg0)
            case .degree:
                return asin(arg0) * 180 / Double.pi
            }
        case .acos:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            switch context.trigonometryMode {
            case .radian:
                return acos(arg0)
            case .degree:
                return acos(arg0) * 180 / Double.pi
            }
        case .atan:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            switch context.trigonometryMode {
            case .radian:
                return atan(arg0)
            case .degree:
                return atan(arg0) * 180 / Double.pi
            }
        case .csc:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            switch context.trigonometryMode {
            case .radian:
                return 1 / __sinpi(arg0 / .pi)
            case .degree:
                return 1 / __sinpi(arg0 / 180)
            }
        case .sec:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            switch context.trigonometryMode {
            case .radian:
                return 1 / __cospi(arg0 / .pi)
            case .degree:
                return 1 / __cospi(arg0 / 180)
            }
        case .cot:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            switch context.trigonometryMode {
            case .radian:
                return 1 / __tanpi(arg0 / .pi)
            case .degree:
                return 1 / __tanpi(arg0 / 180)
            }
        case .acsc:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            switch context.trigonometryMode {
            case .radian:
                return asin(1 / arg0)
            case .degree:
                return asin(1 / arg0) * 180 / Double.pi
            }
        case .asec:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            switch context.trigonometryMode {
            case .radian:
                return acos(1 / arg0)
            case .degree:
                return acos(1 / arg0) * 180 / Double.pi
            }
        case .acot:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            switch context.trigonometryMode {
            case .radian:
                return atan(1 / arg0)
            case .degree:
                return atan(1 / arg0) * 180 / Double.pi
            }
        // hyperbolic trig doesn't distinguish between radian/degree mode
        case .sinh:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            return sinh(arg0)
        case .cosh:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            return cosh(arg0)
        case .tanh:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            return tanh(arg0)
        case .asinh:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            return asinh(arg0)
        case .acosh:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            return acosh(arg0)
        case .atanh:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            return atanh(arg0)
        case .csch:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            return 1 / sinh(arg0)
        case .sech:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            return 1 / cosh(arg0)
        case .coth:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            return 1 / tanh(arg0)
        case .acsch:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            return asinh(1 / arg0)
        case .asech:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            return acosh(1 / arg0)
        case .acoth:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            return atanh(1 / arg0)
        case .matrix(let matrixProperties):
            throw EvaluateError.matrixNotAllowedHere
        case .matrixRREF:
            throw EvaluateError.matrixNotAllowedHere
        case .matrixDeterminant:
            throw EvaluateError.matrixNotAllowedHere
        case .matrixTrace:
            throw EvaluateError.matrixNotAllowedHere
        case .matrixTranspose:
            throw EvaluateError.matrixNotAllowedHere
        case .power:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            let arg1 = try evaluateChildFieldToDouble(index: 1, context: context)
            return pow(arg0, arg1)
        case .enterExponent:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            let arg1 = try evaluateChildFieldToDouble(index: 1, context: context)
            return arg0 * pow(10, arg1)
        case .percent:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            return arg0 / 100
        case .factorial:
            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
            return FunctionLibrary.factorial(arg0)
        case .subtract:
            throw EvaluateError.attemptedToEvaluateOperator(symbol: symbol)
        case .negative:
            throw EvaluateError.attemptedToEvaluateOperator(symbol: symbol)
        case .explicitMultiply:
            throw EvaluateError.attemptedToEvaluateOperator(symbol: symbol)
        }

//        switch symbol {
//        case .constant(_, value: let value):
//            return value
//        case .variable(let variableContext):
//            if let field = context.substitutions[variableContext.name] {
//                return try field.evaluateToDouble(context: context)
//            } else {
//                throw EvaluateError.missingSubstitution(name: variableContext.name)
//            }
//        case .runtimeFunction(let functionContext):
//            if let field = context.substitutions[functionContext.name] {
//                var context = context
//
//                // clear it first
//                context.runtimeArgumentIndexToField = [:]
//
//                // replace arguments with the actual fields
//                for index in fields.indices {
//                    context.runtimeArgumentIndexToField[index] = fields[index]
//                }
//
//                return try field.evaluateToDouble(context: context)
//            } else {
//                throw EvaluateError.missingSubstitution(name: functionContext.name)
//            }
//        case .runtimeArgument(index: let index):
//            if let field = context.runtimeArgumentIndexToField[index] {
//                return try field.evaluateToDouble(context: context)
//            } else {
//                throw EvaluateError.unresolvedArgument(index: index)
//            }
//        case
//            .comma,
//            ._0,
//            ._1,
//            ._2,
//            ._3,
//            ._4,
//            ._5,
//            ._6,
//            ._7,
//            ._8,
//            ._9,
//            .period:
//            throw EvaluateError.unresolvedSymbol(symbol: symbol)
//        case
//            .divide,
//            .cross,
//            .plus,
//            .unambiguousSubtract:
//            throw EvaluateError.attemptedToEvaluateOperator(symbol: symbol)
//        case
//            .dash,
//            .percent,
//            .factorial,
//            .ee:
//            throw EvaluateError.unresolvedSymbol(symbol: symbol)
//        case .equals:
//            throw EvaluateError.attemptedToEvaluateEquals
//        case .leftParenthesis, .rightParenthesis:
//            throw EvaluateError.attemptedToEvaluateParenthesis(symbol: symbol)
//        case .sqrt:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//
//            // call the system `sqrt` function
//            return sqrt(arg0)
//        case .nroot:
//            let n = try evaluateChildFieldToDouble(index: 0, context: context)
//            let base = try evaluateChildFieldToDouble(index: 1, context: context)
//            let power = Double(1) / n
//            return pow(base, power)
//        case .powOperator:
//            throw EvaluateError.unresolvedSymbol(symbol: symbol)
//        case .powWithField:
//            throw EvaluateError.unresolvedSymbol(symbol: symbol)
//        case .ln:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            return log(arg0)
//        case .log:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            return log10(arg0)
//        case .loga:
//            let base = try evaluateChildFieldToDouble(index: 0, context: context)
//            let value = try evaluateChildFieldToDouble(index: 1, context: context)
//            return FunctionLibrary.logC(value: value, base: base)
//        case .abs:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            return abs(arg0)
//        case .floor:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            return floor(arg0)
//        case .ceil:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            return ceil(arg0)
//        case .round:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            return round(arg0)
//        case .sign:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            return Double(FunctionLibrary.sign(value: arg0))
//        case .mod:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            let arg1 = try evaluateChildFieldToDouble(index: 1, context: context)
//            return fmod(arg0, arg1)
//        case .npr:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            let arg1 = try evaluateChildFieldToDouble(index: 1, context: context)
//            return FunctionLibrary.npr(n: arg0, r: arg1)
//        case .ncr:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            let arg1 = try evaluateChildFieldToDouble(index: 1, context: context)
//            return FunctionLibrary.ncr(n: arg0, r: arg1)
//        case .numericalDifferentiation:
//
//            // MARK: - TODO
//
//            return 0
//        case .numericalIntegration:
//
//            // MARK: - TODO
//
//            return 0
//        case .summation:
//
//            let (lowerBound, upperBound, variableName) = try getArgumentsForAggregate(context: context)
//
//            if lowerBound > upperBound {
//                return 0
//            }
//
//            let sum = try FunctionLibrary.kahanSum(closedRange: lowerBound ... upperBound) { index in
//
//                var context = context
//                // e.g. n = 0
//                context.substitutions[variableName] = NodeField(nodes: [Node(symbol: .simpleValue(Double(index)))])
//                // e.g. 2n
//                let value = try evaluateChildFieldToDouble(index: 2, context: context)
//                return value
//            }
//
//            return sum
//        case .product:
//            let (lowerBound, upperBound, variableName) = try getArgumentsForAggregate(context: context)
//
//            if lowerBound > upperBound {
//                return 1
//            }
//
//            var product = Double(1)
//            for index in lowerBound ... upperBound {
//                // e.g. n = 0
//                var context = context
//                context.substitutions[variableName] = NodeField(nodes: [Node(symbol: .simpleValue(Double(index)))])
//
//                // e.g. 2n
//                let value = try evaluateChildFieldToDouble(index: 2, context: context)
//
//                product *= value
//            }
//
//            return product
//
//        case .fraction:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            let arg1 = try evaluateChildFieldToDouble(index: 1, context: context)
//            return arg0 / arg1
//        case .sin:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            switch context.trigonometryMode {
//            case .radian:
//                return __sinpi(arg0 / .pi)
//            case .degree:
//                return __sinpi(arg0 / 180)
//            }
//        case .cos:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            switch context.trigonometryMode {
//            case .radian:
//                return __cospi(arg0 / .pi)
//            case .degree:
//                return __cospi(arg0 / 180)
//            }
//        case .tan:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            switch context.trigonometryMode {
//            case .radian:
//                return __tanpi(arg0 / .pi)
//            case .degree:
//                return __tanpi(arg0 / 180)
//            }
//        case .asin:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            switch context.trigonometryMode {
//            case .radian:
//                return asin(arg0)
//            case .degree:
//                return asin(arg0) * 180 / Double.pi
//            }
//        case .acos:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            switch context.trigonometryMode {
//            case .radian:
//                return acos(arg0)
//            case .degree:
//                return acos(arg0) * 180 / Double.pi
//            }
//        case .atan:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            switch context.trigonometryMode {
//            case .radian:
//                return atan(arg0)
//            case .degree:
//                return atan(arg0) * 180 / Double.pi
//            }
//        case .csc:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            switch context.trigonometryMode {
//            case .radian:
//                return 1 / __sinpi(arg0 / .pi)
//            case .degree:
//                return 1 / __sinpi(arg0 / 180)
//            }
//        case .sec:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            switch context.trigonometryMode {
//            case .radian:
//                return 1 / __cospi(arg0 / .pi)
//            case .degree:
//                return 1 / __cospi(arg0 / 180)
//            }
//        case .cot:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            switch context.trigonometryMode {
//            case .radian:
//                return 1 / __tanpi(arg0 / .pi)
//            case .degree:
//                return 1 / __tanpi(arg0 / 180)
//            }
//        case .acsc:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            switch context.trigonometryMode {
//            case .radian:
//                return asin(1 / arg0)
//            case .degree:
//                return asin(1 / arg0) * 180 / Double.pi
//            }
//        case .asec:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            switch context.trigonometryMode {
//            case .radian:
//                return acos(1 / arg0)
//            case .degree:
//                return acos(1 / arg0) * 180 / Double.pi
//            }
//        case .acot:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            switch context.trigonometryMode {
//            case .radian:
//                return atan(1 / arg0)
//            case .degree:
//                return atan(1 / arg0) * 180 / Double.pi
//            }
//
//        // hyperbolic trig doesn't distinguish between radian/degree mode
//        case .sinh:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            return sinh(arg0)
//        case .cosh:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            return cosh(arg0)
//        case .tanh:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            return tanh(arg0)
//        case .asinh:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            return asinh(arg0)
//        case .acosh:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            return acosh(arg0)
//        case .atanh:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            return atanh(arg0)
//        case .csch:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            return 1 / sinh(arg0)
//        case .sech:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            return 1 / cosh(arg0)
//        case .coth:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            return 1 / tanh(arg0)
//        case .acsch:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            return asinh(1 / arg0)
//        case .asech:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            return acosh(1 / arg0)
//        case .acoth:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            return atanh(1 / arg0)
//        case .matrix:
//            throw EvaluateError.matrixNotAllowedHere
//        case .matrixRREF:
//            throw EvaluateError.matrixNotAllowedHere
//        case .matrixDeterminant:
//            // TODO: Matrix
//            throw EvaluateError.matrixNotAllowedHere
////            let arg0 = try evaluateChildFieldToMatrix(index: 0, context: context)
////            return try arg0.computeDeterminant()
//        case .matrixTrace:
//            // TODO: Matrix
//            throw EvaluateError.matrixNotAllowedHere
//
////            let arg0 = try evaluateChildFieldToMatrix(index: 0, context: context)
////            return try arg0.computeTrace()
//        case .matrixInverse:
//            throw EvaluateError.matrixNotAllowedHere
//        case .matrixTranspose:
//            throw EvaluateError.matrixNotAllowedHere
//        case .unambiguousPower:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            let arg1 = try evaluateChildFieldToDouble(index: 1, context: context)
//            return pow(arg0, arg1)
//        case .unambiguousEE:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            let arg1 = try evaluateChildFieldToDouble(index: 1, context: context)
//            return arg0 * pow(10, arg1)
//        case .unambiguousPercent:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            return arg0 / 100
//        case .unambiguousFactorial:
//            let arg0 = try evaluateChildFieldToDouble(index: 0, context: context)
//            return FunctionLibrary.factorial(arg0)
//        case .unambiguousNegative:
//            throw EvaluateError.unresolvedSymbol(symbol: symbol)
//        case .explicitMultiplication:
//            throw EvaluateError.unresolvedSymbol(symbol: symbol)
//        case .simpleValue(let value):
//            return value
//        }
    }
}
