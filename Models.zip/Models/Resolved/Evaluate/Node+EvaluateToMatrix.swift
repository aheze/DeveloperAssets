//
//  Node+EvaluateToMatrix.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 3/27/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

//extension Node {
//    func evaluateChildFieldToMatrix(index: Int, context: EvaluateContext) throws -> Matrix {
//        let field = try getChildField(index: index)
//        return try field.evaluateToMatrix(context: context)
//    }
//}

//extension Node {
//    func evaluateToMatrix(context: EvaluateContext) throws -> Matrix {
//        switch symbol {
//        case .constant(name: let name, value: let value):
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .variable:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .runtimeFunction:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .runtimeArgument(index: let index):
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .comma:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case ._0:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case ._1:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case ._2:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case ._3:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case ._4:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case ._5:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case ._6:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case ._7:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case ._8:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case ._9:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .period:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .divide:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .cross:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .plus:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .dash:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .percent:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .factorial:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .ee:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .equals:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .leftParenthesis:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .rightParenthesis:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .sqrt:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .nroot:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .powOperator:
//            throw EvaluateError.unresolvedSymbol(symbol: symbol)
//        case .powWithField:
//            throw EvaluateError.unresolvedSymbol(symbol: symbol)
//        case .ln:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .log:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .loga:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .abs:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .floor:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .ceil:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .round:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .sign:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .mod:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .npr:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .ncr:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .numericalDifferentiation:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .numericalIntegration:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .summation:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .product:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .fraction:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .sin:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .cos:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .tan:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .asin:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .acos:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .atan:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .csc:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .sec:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .cot:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .acsc:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .asec:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .acot:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .sinh:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .cosh:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .tanh:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .asinh:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .acosh:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .atanh:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .csch:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .sech:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .coth:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .acsch:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .asech:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .acoth:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .matrix(let matrixProperties):
//
//            do {
//                let contents = try fields.map {
//                    try $0.evaluateToDouble(context: context)
//                }
//                return Matrix(rowsCount: matrixProperties.rowsCount, colsCount: matrixProperties.colsCount, contents: contents)
//            } catch {
//                throw EvaluateError.couldNotEvaluateMatrix
//            }
//
//        case .matrixRREF:
//            let arg0 = try evaluateChildFieldToMatrix(index: 0, context: context)
//            return arg0.computeRREF()
//        case .matrixDeterminant:
//            // handled in evaluateToDouble
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .matrixTrace:
//            // handled in evaluateToDouble
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .matrixInverse:
//            let arg0 = try evaluateChildFieldToMatrix(index: 0, context: context)
//            return try arg0.inverse()
//        case .matrixTranspose:
//            let arg0 = try evaluateChildFieldToMatrix(index: 0, context: context)
//            return arg0.transpose()
//        case .unambiguousPower:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .unambiguousEE:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .unambiguousPercent:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .unambiguousFactorial:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .unambiguousSubtract:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .unambiguousNegative:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .explicitMultiplication:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        case .simpleValue:
//            throw EvaluateError.matrixEvaluationUnsupportedSymbol
//        }
//
//        return Matrix(rowsCount: 1, colsCount: 1, contents: [0])
//    }
//}
