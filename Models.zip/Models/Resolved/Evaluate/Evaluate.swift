//
//  Evaluate.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 3/27/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

struct EvaluateContext {
    var trigonometryMode = TrigonometryMode.radian

    var substitutions = [String: NodeField]()

    // when evaluating a function, the function passes its arguments
    // to the newly-substituted field.
    var runtimeArgumentIndexToField = [Int: NodeField]()

    enum TrigonometryMode {
        case radian
        case degree
    }
}

enum EvaluateError: Error, LocalizedError {
    case missingSubstitution(name: String)
    case unresolvedArgument(index: Int)
    case unresolvedSymbol(symbol: Symbol)
    case attemptedToEvaluateOperator(symbol: Symbol)
    case attemptedToEvaluateEquals
    case attemptedToEvaluateComma
    case attemptedToEvaluateParenthesis(symbol: Symbol)
    
    case divideByZero

    case internalErrorOutOfBoundsIndex
    case missingVariableAssignmentInSum
    case matrixNotAllowedHere
    case couldNotEvaluateMatrix
    
    case intIsTooBig

    case matrixEvaluationUnsupportedSymbol
    
    var errorDescription: String? {
        switch self {
        case .missingSubstitution(let name):
            return "missingSubstitution: \(name)"
        case .unresolvedArgument(let index):
            return "unresolvedArgument: \(index)"
        case .unresolvedSymbol(let symbol):
            return "unresolvedSymbol: \(symbol)"
        case .attemptedToEvaluateOperator(let symbol):
            return "attemptedToEvaluateOperator: \(symbol)"
        case .attemptedToEvaluateEquals:
            return "attemptedToEvaluateEquals"
        case .attemptedToEvaluateComma:
            return "attemptedToEvaluateComma"
        case .attemptedToEvaluateParenthesis(let symbol):
            return "attemptedToEvaluateParenthesis: \(symbol)"
        case .divideByZero:
            return "divideByZero"
        case .internalErrorOutOfBoundsIndex:
            return "internalErrorOutOfBoundsIndex"
        case .missingVariableAssignmentInSum:
            return "missingVariableAssignmentInSum"
        case .matrixNotAllowedHere:
            return "matrixNotAllowedHere"
        case .couldNotEvaluateMatrix:
            return "couldNotEvaluateMatrix"
        case .intIsTooBig:
            return "intIsTooBig"
        case .matrixEvaluationUnsupportedSymbol:
            return "matrixEvaluationUnsupportedSymbol"
        }
    }
}


