//
//  NodeField+EvaluateToNumber.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 3/27/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

extension NodeField {
    func evaluateToDouble(context: EvaluateContext = EvaluateContext()) throws -> Double {
        // adapted from https://www.naukri.com/code360/library/expression-evaluation-using-stack
        var operands = [Double]() // Operand stack
        var operations = [Symbol.EvaluationNode.Operation]() // Operator stack
        var index = 0
        while index < nodes.count {
            let node = nodes[index]
            
            if let evaluationNode = node.symbol.evaluationNode {
                switch evaluationNode {
                case .operand(let double):
                    operands.append(double)
                case .operation(let operation):
                    switch operation {
                    case .divide, .multiply, .subtract, .add:
                        while !operations.isEmpty && operation.precedence <= operations.last!.precedence {
                            let output = try performOperation(&operands, &operations)
                            operands.append(output)
                        }
                        operations.append(operation)
                    case .leftParenthesis:
                        operations.append(.leftParenthesis)
                    case .rightParenthesis:
                        while operations.last! != .leftParenthesis {
                            let output = try performOperation(&operands, &operations)
                            operands.append(output)
                        }
                        operations.removeLast() // Pop the '('
                    }
                }
            } else {
                let double = try node.evaluateToDouble(context: context)
                operands.append(double)
            }
            
            index += 1
        }
        
        while !operations.isEmpty {
            let output = try performOperation(&operands, &operations)
            operands.append(output)
        }
        
        if operands.isEmpty {
            throw EvaluateError.internalErrorOutOfBoundsIndex
        } else {
            return operands.removeLast()
        }
    }
    
    func performOperation(_ operands: inout [Double], _ operations: inout [Symbol.EvaluationNode.Operation]) throws -> Double {
        guard operands.count >= 2 else {
            throw EvaluateError.internalErrorOutOfBoundsIndex
        }
        
        let a = operands.removeLast()
        let b = operands.removeLast()
        let operation = operations.removeLast()
        
        switch operation {
        case .divide:
            if a == 0 {
                throw EvaluateError.divideByZero
            }
                
            return b / a
        case .multiply:
            return b * a
        case .subtract:
            return b - a
        case .add:
            return b + a
        case .leftParenthesis:
            return 0
        case .rightParenthesis:
            return 0
        }
    }
}

// import Foundation
//
// class Main {
//    func evaluate(_ exp: String) -> Int {
//
//    }
//
//
// }
//
//// Usage
// let main = Main()
// let infixExpression = "2 * (5 *(3+6))/5-2"
// print(main.evaluate(infixExpression))
