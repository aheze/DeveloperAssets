//
//  FunctionLibrary+Double.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 3/30/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

extension FunctionLibrary {
    // from https://stackoverflow.com/a/35886846/14351818
    static func logC(value: Double, base: Double) -> Double {
        return log(value) / log(base)
    }

    static func sign(value: Double) -> Int {
        if value == 0 {
            return 0
        } else if value > 0 {
            return 1
        } else {
            return -1
        }
    }

    static func factorial(_ x: Double) -> Double {
        tgamma(x + 1)
    }

    // for positive n
    static func nprRaw(n: Double, r: Double) -> Double {
        let numerator = factorial(n)
        let denominator = factorial(n - r)
        let result = numerator / denominator
        return result
    }

    static func npr(n: Double, r: Double) -> Double {
        return ncr(n: n, r: r) * factorial(r)
    }

    // for positive n
    static func ncrRaw(n: Double, r: Double) -> Double {
        nprRaw(n: n, r: r) / factorial(r)
    }

    static func ncr(n: Double, r: Double) -> Double {
        if n >= 0 {
            return ncrRaw(n: n, r: r)
        } else {
            // reference: https://www.quora.com/What-will-be-the-outcome-if-n-is-negative-in-nCr-I-found-1c2-1-and-1c3-10-Is-it-logical-somehow
            // also see: https://www.reddit.com/r/askmath/comments/17h0rqy/decomposing_xn_to_permutations_is_there_a_general/
            let coefficient = pow(-1, r)
            return coefficient * ncrRaw(n: -n + r - 1, r: r)
        }
    }

    // symmetric quotient rule
    static func derive(xValue: Double, step: Double = 0.001, function: (Double) -> Double) -> Double {
        let result = (function(xValue + step) - function(xValue - step)) / (2 * step)
        return result
    }

    static func kahanSum(closedRange: ClosedRange<Int>, value: (Int) throws -> Double) rethrows -> Double {
        try kahanSum(range: closedRange.lowerBound ..< closedRange.upperBound + 1, value: value)
    }

    static func kahanSum(range: Range<Int>, value: (Int) throws -> Double) rethrows -> Double {
        var sum = Double(0)

        // use Kahan summation algorithm to account for error
        // https://en.wikipedia.org/wiki/Kahan_summation_algorithm
        var correction = Double(0)
        for index in range.lowerBound ..< range.upperBound {
            let value = try value(index)

            // Adjust the current Double by the accumulated errors to correct it before adding

            let y = value - correction
            let total = sum + y

            // Recalculate the small error by comparing the adjusted sum to the previous sum
            // adjust the error tracker (c) for the next iteration
            correction = (total - sum) - y
            sum = total
        }

        return sum

//        var sum = Double(0)
//
//        // use Kahan summation algorithm to account for error
//        // https://en.wikipedia.org/wiki/Kahan_summation_algorithm
//        var correction = Double(0)
//        for index in lowerBound ... upperBound {
//            // e.g. n = 0
//            var context = context
//            context.substitutions[variableName] = NodeField(nodes: [Node(symbol: .simpleValue(Double(index)))])
//
//            // e.g. 2n
//            let value = try evaluateChildFieldToDouble(index: 2, context: context)
//
//            // Adjust the current Double by the accumulated errors to correct it before adding
//
//            let y = value - correction
//            let total = sum + y
//
//            // Recalculate the small error by comparing the adjusted sum to the previous sum
//            // adjust the error tracker (c) for the next iteration
//            correction = (total - sum) - y
//            sum = total
//        }
    }
}
