//
//  FunctionLibrary+Matrix.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 3/30/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

extension FunctionLibrary {}
