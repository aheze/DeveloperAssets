//
//  FunctionLibrary.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 3/25/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

enum FunctionLibrary {
    enum FunctionError: Error {}
}
