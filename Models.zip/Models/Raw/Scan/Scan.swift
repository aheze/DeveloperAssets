//
//  Scan.swift
//  MetalMathTest
//  
//  Created by Andrew Zheng (github.com/aheze) on 3/27/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

enum ScanTarget {
    case scanForBoundsBeforeOperator(preferShorter: Bool)
    case scanForMatchingLeftParenthesis
    case scanForMatchingRightParenthesis
}

enum ScanError: String, Error, LocalizedError {
    
    case missingLeftHandSide
    case missingRightHandSide
    case unexpectedOperator
    case unexpectedLeftParenthesis
    case unexpectedRightParenthesis
    case unexpectedComma
    case unexpectedMinusAtEnd
    case unexpectedEquals
    case internalError
    case couldNotParseBounds
    
    var errorDescription: String? {
        return rawValue
    }
}
