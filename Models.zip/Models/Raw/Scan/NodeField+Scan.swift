//
//  NodeField+Scan.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 3/24/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

extension NodeField {
    func scanLeftForEndIndex(startIndex: Int) throws -> Int {
        if startIndex < 0 {
            throw ScanError.missingLeftHandSide
        }

        return try scanForEndIndex(startIndex: startIndex, right: false)
    }

    func scanRightForEndIndex(startIndex: Int) throws -> Int {
        if startIndex >= nodes.count {
            throw ScanError.missingRightHandSide
        }

        return try scanForEndIndex(startIndex: startIndex, right: true)
    }

    // determine the scan type base on startIndex
    func scanForEndIndex(startIndex: Int, right: Bool) throws -> Int {
        let startNode = nodes[startIndex]
        let scanTarget = try getScanTargetForEnd(startNode: startNode, right: right)
        return try scan(startIndex: startIndex, scanTarget: scanTarget, right: right)
    }

    // start scanning at startIndex + 1
    func scan(startIndex: Int, scanTarget: ScanTarget, right: Bool) throws -> Int {
        var foundIndex: Int?

        switch scanTarget {
        case .scanForBoundsBeforeOperator(let preferShorter):
            let initial = nodes[startIndex]

            if preferShorter {
                switch initial.symbol {
                case
                    .divide,
                    .multiply,
                    .add,
                    .subtract,
                    .ambiguousDash:
                    return startIndex
                default:
                    break
                }
            }

            if right {
                var balance = 0
                var previousIndex = startIndex
                loop: for (index, node) in scanRight(startIndex: startIndex + 1) {
                    switch node.symbol {
                    case .leftParenthesis:
                        balance += 1
                    case .rightParenthesis:
                        balance -= 1
                    default:
                        break
                    }

                    if balance < 0 {
                        throw ScanError.unexpectedRightParenthesis
                    } else if balance == 0 {
                        if preferShorter {
                            if node.symbol.isPartialValue != initial.symbol.isPartialValue {
                                foundIndex = previousIndex
                                break loop
                            }
                        }

                        switch node.symbol {
                        case
                            .divide,
                            .multiply,
                            .add,
                            .subtract,
                            .ambiguousDash:
                            foundIndex = previousIndex
                            break loop
                        default:
                            break
                        }
                    }

                    previousIndex = index
                }

                // no operator was found, so just return the max index
                if foundIndex == nil {
                    return nodes.count - 1
                }
            } else {
                var balance = 0
                var previousIndex = startIndex

                loop: for (index, node) in scanLeft(startIndex: startIndex - 1) {
                    switch node.symbol {
                    case .leftParenthesis:
                        balance -= 1
                    case .rightParenthesis:
                        balance += 1
                    default:
                        break
                    }

                    if balance < 0 {
                        throw ScanError.unexpectedLeftParenthesis
                    } else if balance == 0 {
                        if preferShorter {
                            if node.symbol.isPartialValue != initial.symbol.isPartialValue {
                                foundIndex = previousIndex
                                break loop
                            }
                        }

                        switch node.symbol {
                        case
                            .divide,
                            .multiply,
                            .add,
                            .subtract,
                            .ambiguousDash:
                            foundIndex = previousIndex
                            break loop
                        default:
                            break
                        }
                    }

                    previousIndex = index
                }

                // no operator was found, so just return the index most to the left
                if foundIndex == nil {
                    return 0
                }
            }
        case .scanForMatchingLeftParenthesis:

            // starts with 1, because we need to find 1 left parenthesis
            var balance = 1
            for (index, node) in scanLeft(startIndex: startIndex - 1) {
                switch node.symbol {
                case .leftParenthesis:
                    balance -= 1
                case .rightParenthesis:
                    balance += 1
                default:
                    break
                }

                if balance == 0 {
                    return index
                }
            }
        case .scanForMatchingRightParenthesis:
            var balance = 1
            for (index, node) in scanRight(startIndex: startIndex + 1) {
                switch node.symbol {
                case .leftParenthesis:
                    balance += 1
                case .rightParenthesis:
                    balance -= 1
                default:
                    break
                }

                if balance == 0 {
                    return index
                }
            }
        }

        if let foundIndex {
            return foundIndex
        } else {
            throw ScanError.couldNotParseBounds
        }
    }

    // target the "closing" index
    func getScanTargetForEnd(startNode: Node, right: Bool) throws -> ScanTarget {
        switch startNode.symbol.category {
        case .partialValue:
            return .scanForBoundsBeforeOperator(preferShorter: false)
        case .simpleValue:
            return .scanForBoundsBeforeOperator(preferShorter: false)
        case .constantValue:
            return .scanForBoundsBeforeOperator(preferShorter: false)
        case .needsSubstitution:
            return .scanForBoundsBeforeOperator(preferShorter: false)
        case .mathOperator:
            throw ScanError.unexpectedOperator
        case .unresolvedOperator:
            throw ScanError.unexpectedOperator
        case .dash:
            if right {
                // the dash should be considered a negative sign
                return .scanForBoundsBeforeOperator(preferShorter: false)
            } else {
                // the first element is a negative, which means there's an extra negative at the end
                throw ScanError.unexpectedMinusAtEnd
            }
        case .equals:
            throw ScanError.unexpectedEquals
        case .leftParenthesis:
            if right {
                return .scanForMatchingRightParenthesis
            } else {
                throw ScanError.unexpectedLeftParenthesis
            }
        case .rightParenthesis:
            if right {
                throw ScanError.unexpectedRightParenthesis
            } else {
                return .scanForMatchingLeftParenthesis
            }
        case .comma:
            throw ScanError.unexpectedComma
        case .hasFields:
            return .scanForBoundsBeforeOperator(preferShorter: false)
        case .resolved:
            return .scanForBoundsBeforeOperator(preferShorter: false)
        }
    }
}

extension NodeField {
    func scanLeft(startIndex: Int) -> ScanLeftIterator {
        return ScanLeftIterator(startIndex: startIndex, nodes: nodes)
    }

    func scanRight(startIndex: Int) -> ScanRightIterator {
        return ScanRightIterator(startIndex: startIndex, nodes: nodes)
    }
}

struct ScanLeftIterator: Sequence, IteratorProtocol {
    var currentIndex: Int
    let nodes: [Node]

    init(startIndex: Int, nodes: [Node]) {
        self.currentIndex = startIndex
        self.nodes = nodes
    }

    mutating func next() -> (Int, Node)? {
        while currentIndex >= 0 {
            let node = nodes[currentIndex]
            let index = currentIndex
            currentIndex -= 1
            return (index, node)
        }
        return nil
    }
}

struct ScanRightIterator: Sequence, IteratorProtocol {
    var currentIndex: Int
    let nodes: [Node]

    init(startIndex: Int, nodes: [Node]) {
        self.currentIndex = startIndex
        self.nodes = nodes
    }

    mutating func next() -> (Int, Node)? {
        while currentIndex < nodes.count {
            let node = nodes[currentIndex]
            let index = currentIndex
            currentIndex += 1
            return (index, node)
        }
        return nil
    }
}
