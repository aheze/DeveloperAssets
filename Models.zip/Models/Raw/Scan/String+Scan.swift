//
//  String+Scan.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 4/7/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

extension [String] {
    // 0. the resulting integer
    // 1. how many chars the int is
    func scanForInteger(startingIndex: Int, right: Bool) -> (int: Int, count: Int)? {
        var integerString = ""

        if right {
            loop: for index in startingIndex ..< count {
                let char = self[index]
                switch char {
                case "0", "1", "2", "3", "4", "5", "6", "7", "8", "9":
                    integerString += char
                default:
                    break loop
                }
            }
        } else {
            loop: for index in (0 ... startingIndex).reversed() {
                let char = self[index]
                switch char {
                case "0", "1", "2", "3", "4", "5", "6", "7", "8", "9":
                    integerString += char
                default:
                    break loop
                }
            }
        }

        if let int = Int(integerString) {
            return (int, integerString.count)
        }

        return nil
    }
}
