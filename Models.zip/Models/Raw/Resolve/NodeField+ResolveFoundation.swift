//
//  NodeField+ResolveFoundation.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 3/24/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

extension NodeField {
    func resolveFoundation() throws -> NodeField {
        do {
            var copy = self
            try copy.resolveFoundationInPlace()
            return copy
        } catch {
            throw error
        }
    }
}

extension NodeField {
    mutating func resolveFoundationInPlace(context: ResolveContext = ResolveContext()) throws {
        var index = 0
        while index < nodes.count {
            let node = nodes[index]

            switch node.symbol {
            case .ambiguousDash:

                let nextIndex = index + 1
                if nextIndex >= nodes.count {
                    throw ResolveError.unexpectedMinusAtEnd
                }

                let previousIsStartParenthesis = {
                    if index > 0, case .leftParenthesis = self.nodes[index - 1].symbol {
                        return true
                    }
                    return false
                }()

                let isAtStart = (index == 0) || previousIsStartParenthesis
                let nextIsPartial = nodes[nextIndex].symbol.isPartialValue

                if isAtStart, nextIsPartial {
                    nodes[index] = Node(symbol: .negative)
                } else {
                    nodes[index] = Node(symbol: .subtract)
                }
            case .ambiguousPowOperator:
                let functionIndex = try replaceOperatorWithFunction(context: context, index: index, outputSymbol: .power)
                index = functionIndex + 1
                continue
            case .ambiguousPowWithField:
                guard let field = node.fields.first else {
                    throw ResolveError.missingFieldForPow
                }

                let leftStartIndex = index - 1
                let leftEndIndex = try scanLeftForEndIndex(startIndex: leftStartIndex)

                let left = nodes[leftEndIndex ... leftStartIndex]

                try replaceSubrange(
                    context: context,
                    subrange: leftEndIndex ... index,
                    outputSymbol: .power,
                    fields: [
                        NodeField(nodes: Array(left)),
                        field
                    ]
                )

                index = leftEndIndex + 1
                continue
            case .ambiguousEE:
                let functionIndex = try replaceOperatorWithFunction(context: context, index: index, outputSymbol: .enterExponent)
                index = functionIndex + 1
                continue
            case .ambiguousPercent:

                // MARK: - Find the value to divide by 100

                let valueStartIndex = index - 1
                let valueEndIndex = try scanLeftForEndIndex(startIndex: valueStartIndex)
                let value = nodes[valueEndIndex ... valueStartIndex]

                // range of "20%"
                let valueToPercentRange = valueEndIndex ... index
                // replace "20%" with "percent(20)"
                try replaceSubrange(
                    context: context,
                    subrange: valueToPercentRange,
                    outputSymbol: .percent,
                    fields: [
                        NodeField(nodes: Array(value))
                    ]
                )

                // MARK: - See if smart percents are applicable (when + or -)

                if context.enableSmartPercents {
                    // Applicable:     5+20% -> 5+(5*20%) = 6
                    //                 5-20% -> 5-(5*20%) = 4
                    // Not applicable: 5*20% -> (5*20%) = 1
                    //                 5/20% -> (5/20%) = 25
                    let operatorIndex = valueEndIndex - 1

                    // make sure there's something to the left of the operator
                    if operatorIndex >= 1 {
                        let operatorNode = nodes[operatorIndex]

                        // MARK: - Find the base to add the smart percent by

                        // e.g. the "5" in "5+20%
                        switch operatorNode.symbol {
                        case .add, .ambiguousDash:
                            let baseStartIndex = operatorIndex - 1
                            let baseEndIndex = try scanLeftForEndIndex(startIndex: baseStartIndex)
                            let base = nodes[baseEndIndex ... baseStartIndex]

                            // insert the "5*" in "5+5*20%"
                            var nodesToInsert = base
                            nodesToInsert.append(Node(symbol: .multiply))
                            nodes.insert(contentsOf: nodesToInsert, at: valueEndIndex)

                            index = valueEndIndex + nodesToInsert.count + 1
                            continue
                        default:
                            break
                        }
                    }
                }

                index = valueEndIndex + 1
                continue

            default:
                break
            }

            // resolve children
            // child fields are already resolved in `replaceOperatorWithFunction`,
            // so when that is called there's no need to resolve again.
            for i in node.fields.indices {
                try nodes[index].fields[i].resolveFoundationInPlace(context: context)
            }

            if context.consolidateValues {
                // is non-nil for `0 1 2 3 4 5 6 7 8 9 . -`
                if let partialValueString = nodes[index].symbol.partialValueString {
                    var string = partialValueString
                    var endIndex = index
                    for (i, n) in scanRight(startIndex: index + 1) {
                        if let p = n.symbol.partialValueString {
                            string += p
                            endIndex = i
                        } else {
                            break
                        }
                    }

                    guard let double = Double(string) else {
                        throw ResolveError.couldNotConvertPartialValueIntoSimpleValue
                    }

                    try replaceSubrange(
                        context: context,
                        subrange: index ... endIndex,
                        outputSymbol: .simpleValue(double),
                        fields: []
                    )

                    index = index + 1
                    continue
                }
            }

            if context.addExplicitMultiplication {
                if index > 0 {
                    let a = nodes[index - 1].symbol.implicitMultiplicationBehavior
                    let b = nodes[index].symbol.implicitMultiplicationBehavior

                    if a.right.priority > b.left.priority {
                        if a.right.multiply {
                            nodes.insert(Node(symbol: .explicitMultiply), at: index)
                            index += 2
                            continue
                        }
                    } else {
                        if b.left.multiply {
                            nodes.insert(Node(symbol: .explicitMultiply), at: index)
                            index += 2
                            continue
                        }
                    }
                }
            }

            index += 1
        }
    }
}

extension NodeField {
    mutating func replaceOperatorWithFunction(context: ResolveContext, index: Int, outputSymbol: Symbol) throws -> Int {
        let leftStartIndex = index - 1
        let leftEndIndex = try scanLeftForEndIndex(startIndex: leftStartIndex)

        let rightStartIndex = index + 1
        let rightEndIndex = try scanRightForEndIndex(startIndex: rightStartIndex)

        let left = nodes[leftEndIndex ... leftStartIndex]
        let right = nodes[rightStartIndex ... rightEndIndex]

        try replaceSubrange(
            context: context,
            subrange: leftEndIndex ... rightEndIndex,
            outputSymbol: outputSymbol,
            fields: [
                NodeField(nodes: Array(left)),
                NodeField(nodes: Array(right))
            ]
        )

        return leftEndIndex
    }

    mutating func replaceSubrange(context: ResolveContext, subrange: ClosedRange<Int>, outputSymbol: Symbol, fields: [NodeField]) throws {
        var fields = fields
        if context.trimExtraParentheses {
            fields = fields.map {
                let nodes = $0.nodes
                if case .leftParenthesis = nodes.first?.symbol, case .rightParenthesis = nodes.last?.symbol {
                    return NodeField(nodes: Array(nodes[1 ..< nodes.count - 1]))
                } else {
                    return $0
                }
            }
        }

        // resolve the replacement node's children
        for index in fields.indices {
            try fields[index].resolveFoundationInPlace(context: context)
        }

        let replacementNode = Node(symbol: outputSymbol, fields: fields)
        var nodes = nodes
        nodes.removeSubrange(subrange)
        nodes.insert(replacementNode, at: subrange.lowerBound)
        self.nodes = nodes
    }
}
