//
//  Node+ResolveFinish.swift
//  MetalMathTest
//  
//  Created by Andrew Zheng (github.com/aheze) on 4/10/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

extension Node {
    func resolveFinish() -> ResolvedNode {
        return ResolvedNode.resolvedNumber(0)
    }
}
