//
//  NodeField+ResolveFinish.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 3/24/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

extension NodeField {
    func resolveFinish() -> ResolvedNodeField {
        var resolvedField = ResolvedNodeField()
        for node in nodes {}
        return resolvedField
    }
}
