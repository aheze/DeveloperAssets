//
//  Resolve.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 3/27/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

struct ResolveContext {
    // useful for calculating tips
    // lets you do shorthand:
    // 5+20% -> 5+(5*20%) = 6
    var enableSmartPercents = true

    // normally when scanning for a matching parenthesis,
    // the scanner will return the index of the match.
    // then the range from (match ... original) contains both leading and trailing parentheses.
    // this setting removes them.
    var trimExtraParentheses = true

    // add explicit "*" signs
    var addExplicitMultiplication = true

    // group partial values together into simple values
    // this will also group partial with simple, and simple with simple
    var consolidateValues = true
}

enum ResolveError: String, Error, LocalizedError {
    case missingFieldForPow
    case unexpectedMinusAtEnd
    case couldNotConvertPartialValueIntoSimpleValue

    var errorDescription: String? {
        return rawValue
    }
}
