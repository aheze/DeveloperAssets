//
//  NodeField+Resolve.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 4/9/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

extension NodeField {
    func resolve() throws -> NodeField {
        try resolveFoundation()
    }
}
