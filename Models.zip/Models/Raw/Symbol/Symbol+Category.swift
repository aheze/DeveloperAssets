//
//  SymbolKind.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 3/24/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

// MARK: Digits

extension Symbol {
    // categorize symbols for easier processing
    enum Category {
        // a single digit
        case partialValue

        // single digits grouped together (happens in `resolve`)
        case simpleValue

        // the value is constant
        case constantValue

        // var, func, or argument
        case needsSubstitution

        case mathOperator
        case unresolvedOperator
        case dash
        case equals

        case leftParenthesis
        case rightParenthesis
        case comma

        case hasFields
        case resolved
    }

    var category: Category {
        switch self {
        case .constant:
            return .constantValue
        case .runtimeVariable, .runtimeFunction, .runtimeArgument:
            return .needsSubstitution
        case
            ._0,
            ._1,
            ._2,
            ._3,
            ._4,
            ._5,
            ._6,
            ._7,
            ._8,
            ._9,
            .period,
            .negative:
            return .partialValue
        case .simpleValue:
            return .simpleValue
        case
            .divide,
            .multiply,
            .subtract,
            .add:
            return .mathOperator
        case
            .ambiguousPowOperator,
            .ambiguousEE,
            .ambiguousPercent,
            .ambiguousFactorial,
            .functionStem:
            return .unresolvedOperator
        case .ambiguousDash:
            return .dash
        case .equals:
            return .equals
        case .leftParenthesis:
            return .leftParenthesis
        case .rightParenthesis:
            return .rightParenthesis
        case .comma:
            return .comma
        case
            .ambiguousPowWithField,
            .sqrt,
            .nroot,
            .ln,
            .log,
            .loga,
            .abs,
            .floor,
            .ceil,
            .round,
            .sign,
            .mod,
            .inverse,
            .npr,
            .ncr,
            .numericalDifferentiation,
            .numericalIntegration,
            .summation,
            .product,
            .fraction,
            .sin,
            .cos,
            .tan,
            .asin,
            .acos,
            .atan,
            .csc,
            .sec,
            .cot,
            .acsc,
            .asec,
            .acot,
            .sinh,
            .cosh,
            .tanh,
            .asinh,
            .acosh,
            .atanh,
            .csch,
            .sech,
            .coth,
            .acsch,
            .asech,
            .acoth,
            .matrix,
            .matrixRREF,
            .matrixDeterminant,
            .matrixTrace,
            .matrixTranspose,
            .enterExponent,
            .percent,
            .factorial,
            .power:
            return .hasFields
        case .explicitMultiply:
            return .resolved
        }
    }

    struct ImplicitMultiplicationBehavior {
        var left: Behavior
        var right: Behavior

        struct Behavior {
            var multiply: Bool

            // when two nodes left and right with different priorities, choose the one with higher priority
            var priority: Int
        }
    }

    // 4sin(x) -> 4*sin(x)
    // 4+sin(x) -> 4+sin(x) (+ has negative implicit behavior)
    var implicitMultiplicationBehavior: ImplicitMultiplicationBehavior {
        switch self {
        case
            ._0,
            ._1,
            ._2,
            ._3,
            ._4,
            ._5,
            ._6,
            ._7,
            ._8,
            ._9,
            .period,
            .negative:
            return ImplicitMultiplicationBehavior(left: .init(multiply: false, priority: 1), right: .init(multiply: false, priority: 1))
        case
            .divide,
            .multiply,
            .subtract,
            .add,
            .ambiguousPowOperator,
            .ambiguousEE,
            .ambiguousPercent,
            .ambiguousFactorial,
            .ambiguousDash,
            .equals,
            .comma:
            return ImplicitMultiplicationBehavior(left: .init(multiply: false, priority: 100), right: .init(multiply: false, priority: 100))
        case .leftParenthesis:
            return ImplicitMultiplicationBehavior(left: .init(multiply: true, priority: 50), right: .init(multiply: false, priority: 100))
        case .rightParenthesis:
            return ImplicitMultiplicationBehavior(left: .init(multiply: false, priority: 100), right: .init(multiply: true, priority: 50))
        case .summation, .product:
            return ImplicitMultiplicationBehavior(left: .init(multiply: true, priority: 50), right: .init(multiply: false, priority: 100))
        case .explicitMultiply:

            // don't add more multiplication around already-explicit multiplication
            return ImplicitMultiplicationBehavior(left: .init(multiply: false, priority: 100), right: .init(multiply: false, priority: 100))
        default:
            return ImplicitMultiplicationBehavior(left: .init(multiply: true, priority: 5), right: .init(multiply: true, priority: 5))
        }
    }

//    var category: Category {
//        switch self {
//        case .constant:
//            return .constantValue
//        case .variable, .runtimeFunction, .runtimeArgument:
//            return .needsSubstitution
//        case
//            ._0,
//            ._1,
//            ._2,
//            ._3,
//            ._4,
//            ._5,
//            ._6,
//            ._7,
//            ._8,
//            ._9,
//            .period,
//            .negative:
//            return .partialValue
//        case .simpleValue:
//            return .simpleValue
//        case
//            .divide,
//            .multiply,
//            .subtract,
//            .add:
//            return .mathOperator
//        case
//            .ambiguousPowOperator,
//            .ambiguousEE,
//            .ambiguousPercent,
//            .ambiguousFactorial:
//            return .unresolvedOperator
//        case .ambiguousDash:
//            return .dash
//        case .equals:
//            return .equals
//        case .leftParenthesis:
//            return .leftParenthesis
//        case .rightParenthesis:
//            return .rightParenthesis
//        case .comma:
//            return .comma
//        case
//            .ambiguousPowWithField,
//            .sqrt,
//            .nroot,
//            .ln,
//            .log,
//            .loga,
//            .abs,
//            .floor,
//            .ceil,
//            .round,
//            .sign,
//            .mod,
//            .inverse,
//            .npr,
//            .ncr,
//            .numericalDifferentiation,
//            .numericalIntegration,
//            .summation,
//            .product,
//            .fraction,
//            .sin,
//            .cos,
//            .tan,
//            .asin,
//            .acos,
//            .atan,
//            .csc,
//            .sec,
//            .cot,
//            .acsc,
//            .asec,
//            .acot,
//            .sinh,
//            .cosh,
//            .tanh,
//            .asinh,
//            .acosh,
//            .atanh,
//            .csch,
//            .sech,
//            .coth,
//            .acsch,
//            .asech,
//            .acoth,
//            .matrix,
//            .matrixRREF,
//            .matrixDeterminant,
//            .matrixTrace,
//            .matrixTranspose,
//            .enterExponent,
//            .percent,
//            .factorial,
//            .power:
//            return .hasFields
//        case .explicitMultiply:
//            return .resolved
//        }
//    }
}
