//
//  Symbol.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 3/24/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

public enum Symbol: Codable, Equatable {
    // ==============================

    // MARK: - Unresolved

    // MARK: Digits

    case _0
    case _1
    case _2
    case _3
    case _4
    case _5
    case _6
    case _7
    case _8
    case _9
    case period

    // MARK: Functions

    // to get the variable's contents, you need to provide it at runtime.
    // the variable's ID is used for matching it to its contents.
    case runtimeVariable(VariableContext)

    // to get the function's contents, you need to provide it at runtime.
    // the function's ID is used for matching it to its contents.
    // parameters are stored in `fields`.
    case runtimeFunction(FunctionContext)

    // use this to access each of a function's parameters, from inside its body.
    case runtimeArgument(index: Int)

    // MARK: Operators

    // could either be subtract or negative
    case ambiguousDash

    // precedence is not determined yet
    case ambiguousPercent
    case ambiguousFactorial
    case ambiguousEE
    case ambiguousPowOperator
    case ambiguousPowWithField

    // ==============================

    // MARK: - Already resolved / unambiguous

    // MARK: Values

    // a single value, e.g. 3.1415926
    case simpleValue(Double)

    // named values
    // e.g. .constant(name: "pi", value: 3.1415926)
    case constant(Constant)

    // MARK: Layout and grouping

    case leftParenthesis
    case rightParenthesis

    case equals

    // for splitting up function arguments
    case comma

    // division, but grouped by numerator and denominator
    case fraction

    // MARK: Already unambiguous operators

    case divide
    case multiply
    case add

    // MARK: Standard functions
    // these are stored separately from the parentheses, to make for easier visual editing
    case functionStem(kind: ResolvedFunction.Kind)
    
    // MARK: Basic functions

    case sqrt
    case nroot
    case ln
    case log
    case loga
    case abs
    case floor
    case ceil
    case round
    case sign
    case mod
    case inverse

    // MARK: Probability

    case npr
    case ncr

    // MARK: Advanced

    case numericalDifferentiation
    case numericalIntegration
    case summation // sigma
    case product // capital pi

    // MARK: Trig functions

    case sin
    case cos
    case tan
    case asin
    case acos
    case atan

    case csc
    case sec
    case cot
    case acsc
    case asec
    case acot

    // MARK: Hyperbolic trig

    case sinh
    case cosh
    case tanh
    case asinh
    case acosh
    case atanh

    case csch
    case sech
    case coth
    case acsch
    case asech
    case acoth

    // MARK: Matrices

    case matrix(MatrixProperties)
    case matrixRREF
    case matrixDeterminant
    case matrixTrace
    case matrixTranspose

    // MARK: - Resolved symbols

    case power
    case enterExponent
    case percent
    case factorial
    case subtract
    case negative
    case explicitMultiply
    
    public struct Constant: Codable, Equatable {
        public var name: String
        public var value: Double
        
        static let e = Constant(name: "e", value: Darwin.M_E)
        static let pi = Constant(name: "pi", value: Double.pi)
        
        public init(name: String, value: Double) {
            self.name = name
            self.value = value
        }
    }

    public struct VariableContext: Codable, Equatable {
        public var name: String // displayed to the user

        public init(name: String) {
            self.name = name
        }
    }

    public struct FunctionContext: Codable, Equatable {
        public var name: String // displayed to the user
        public var numberOfParameters: Int // "arity"

        // add "inline disable" options for each parameter?

        public init(name: String, numberOfParameters: Int) {
            self.name = name
            self.numberOfParameters = numberOfParameters
        }
    }

    // class for easy modification
    public struct MatrixProperties: Codable, Equatable {
        public var rowsCount = 1
        public var colsCount = 1

        public init(rowsCount: Int = 1, colsCount: Int = 1) {
            self.rowsCount = rowsCount
            self.colsCount = colsCount
        }
    }
}
