//
//  Symbol+Count.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 4/7/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

extension Symbol {
    
    // number of fields that it should have
    var fieldsCount: Int {
        switch self {
        case ._0:
            return 0
        case ._1:
            return 0
        case ._2:
            return 0
        case ._3:
            return 0
        case ._4:
            return 0
        case ._5:
            return 0
        case ._6:
            return 0
        case ._7:
            return 0
        case ._8:
            return 0
        case ._9:
            return 0
        case .period:
            return 0
        case .runtimeVariable(let variableContext):
            return 0
        case .runtimeFunction(let functionContext):
            return 0
        case .runtimeArgument(let index):
            return 0
        case .ambiguousDash:
            return 0
        case .ambiguousPercent:
            return 0
        case .ambiguousFactorial:
            return 0
        case .ambiguousEE:
            return 0
        case .ambiguousPowOperator:
            return 0
        case .ambiguousPowWithField:
            return 1
        case .simpleValue(let double):
            return 0
        case .constant(let constant):
            return 0
        case .leftParenthesis:
            return 0
        case .rightParenthesis:
            return 0
        case .equals:
            return 0
        case .comma:
            return 0
        case .fraction:
            return 2
        case .divide:
            return 0
        case .multiply:
            return 0
        case .add:
            return 0
        case .functionStem:
            return 0
        case .sqrt:
            return 1
        case .nroot:
            return 2
        case .ln:
            return 1
        case .log:
            return 1
        case .loga:
            return 2
        case .abs:
            return 1
        case .floor:
            return 1
        case .ceil:
            return 1
        case .round:
            return 1
        case .sign:
            return 1
        case .mod:
            return 2
        case .inverse:
            return 1
        case .npr:
            return 2
        case .ncr:
            return 2
        case .numericalDifferentiation:
            return 2
        case .numericalIntegration:
            return 3
        case .summation:
            return 3
        case .product:
            return 3
        case .sin:
            return 1
        case .cos:
            return 1
        case .tan:
            return 1
        case .asin:
            return 1
        case .acos:
            return 1
        case .atan:
            return 1
        case .csc:
            return 1
        case .sec:
            return 1
        case .cot:
            return 1
        case .acsc:
            return 1
        case .asec:
            return 1
        case .acot:
            return 1
        case .sinh:
            return 1
        case .cosh:
            return 1
        case .tanh:
            return 1
        case .asinh:
            return 1
        case .acosh:
            return 1
        case .atanh:
            return 1
        case .csch:
            return 1
        case .sech:
            return 1
        case .coth:
            return 1
        case .acsch:
            return 1
        case .asech:
            return 1
        case .acoth:
            return 1
        case .matrix(let matrixProperties):
            return matrixProperties.rowsCount * matrixProperties.colsCount
        case .matrixRREF:
            return 1
        case .matrixDeterminant:
            return 1
        case .matrixTrace:
            return 1
        case .matrixTranspose:
            return 1
        case .power:
            return 2
        case .enterExponent:
            return 2
        case .percent:
            return 1
        case .factorial:
            return 1
        case .subtract:
            return 0
        case .negative:
            return 0
        case .explicitMultiply:
            return 0
        }
    }
}
