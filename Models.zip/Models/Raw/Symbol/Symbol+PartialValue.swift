//
//  Symbol+PartialValue.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 4/7/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

extension Symbol {
    var isPartialValue: Bool {
        category == .partialValue
    }

    var partialValueString: String? {
        switch self {
        case ._0:
            return "0"
        case ._1:
            return "1"
        case ._2:
            return "2"
        case ._3:
            return "3"
        case ._4:
            return "4"
        case ._5:
            return "5"
        case ._6:
            return "6"
        case ._7:
            return "7"
        case ._8:
            return "8"
        case ._9:
            return "9"
        case .period:
            return "."
        case .negative:
            return "-"
        default:
            return nil
        }
    }
}
