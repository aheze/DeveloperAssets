//
//  Symbol+Evaluate.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 3/25/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

extension Symbol {
    var evaluationNode: EvaluationNode? {
        switch self {
        case .simpleValue(let double):
            return .operand(double)
        case .divide:
            return .operation(.divide)
        case .multiply:
            return .operation(.multiply)
        case .explicitMultiply:
            return .operation(.multiply)
        case .subtract:
            return .operation(.subtract)
        case .add:
            return .operation(.add)
        case .leftParenthesis:
            return .operation(.leftParenthesis)
        case .rightParenthesis:
            return .operation(.rightParenthesis)
        default:
            return nil
        }
    }

    enum EvaluationNode {
        case operand(Double)
        case operation(Operation)

        enum Operation {
            case divide
            case multiply
            case subtract
            case add
            case leftParenthesis
            case rightParenthesis

            var precedence: Int {
                switch self {
                case .add, .subtract:
                    return 1
                case .multiply, .divide:
                    return 2
                default:
                    return -1
                }
            }
        }
    }
}
