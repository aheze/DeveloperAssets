//
//  Import.swift
//  MetalMathTest
//  
//  Created by Andrew Zheng (github.com/aheze) on 4/7/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

struct ImportContext {
    var constants: [Symbol.Constant] = [.e, .pi]
    var variableNames = [String]()
    var functionNames = [String]()
}

enum ImportError: Error, LocalizedError {
    case expectedIntAfterArgument
    case unexpectedToken(String)
    case internalError(String)
    case outOfBounds(Int)
    
    var errorDescription: String? {
        switch self {
        case .expectedIntAfterArgument:
            return "expectedIntAfterArgument"
        case .unexpectedToken(let string):
            return "unexpectedToken(\(string))"
        case .internalError(let string):
            return "internalError(\(string))"
        case .outOfBounds(let index):
            return "outOfBounds(\(index))"
        }
    }
}
