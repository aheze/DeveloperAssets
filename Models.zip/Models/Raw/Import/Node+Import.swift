//
//  Node+Import.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 4/7/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

extension NodeField {
    init(string: String, context: ImportContext = ImportContext()) throws {
        let string = Array(string).map { "\($0)" }
        
        // create a dummy node with one field
        var resultNode = Node(symbol: .simpleValue(0)) {}
        
        var stringIndex = 0
        
        try resultNode.importFromString(string: string, stringIndex: &stringIndex, startParenthesesBalance: 0, context: context)
            
        nodes = resultNode.fields.first?.nodes ?? []
    }
    
//    static let test2 = "sin(2/3)+frac(2,900)+abs(abs(abs()))+sin(2)+cos"
//    static let test2 = "sinh(2/3)+arg0+abs(abs(abs()))+sin(2)+cos+sin"
//    static let test2 = #"sqrt(sqrt(sqrt(5)))+frac(3"e","pi")+2+sinh(5+sqrt(654^(2+3^(2))))+5)"#
//    static let test2 = #"sqrt(sqrt(sqrt(5)))+frac(3"var","e")+2+sin(5+sqrt(654^(2+3^(2^(2^(2)))))+5)"#
//    static let test2 = "sin(cos(5))"
//    static let test2 = "5^(3)"
//    static let test2 = "5ᴇ3"
    static let test2 = "s"
}

extension Node {
    // returns:
    // 1. the populated node
    // 2. the index to continue from
    // this function is on Node so that we can build a node field from a bunch of nodes
    // if we put the function on NodeField, we can't separate the fields properly
    mutating func importFromString(string: [String], stringIndex: inout Int, startParenthesesBalance: Int, context: ImportContext) throws {
        // we'll append the string character by character to here
        var accumulatedSymbolString = ""
        
        // the field that we'll be appending nodes to
        var targetFieldIndex = 0
        
        // number of parentheses. Starts at 1, because there was an open parentheses.
        var parenthesesBalance = startParenthesesBalance
        
        // delimiter for variables and constants
        var delimiterActive = false
        
        // loop over the string
        while stringIndex < string.count {
            let char = string[stringIndex]
            
            switch char {
            case Symbol.StringRepresentation.delimiter:
                delimiterActive.toggle()
                
                if delimiterActive == false {
                    if let constant = context.constants.first(where: { $0.name == accumulatedSymbolString }) {
                        let node = Node(symbol: .constant(constant))
                        fields[targetFieldIndex].nodes.append(node)
                    } else {
                        let node = Node(symbol: .runtimeVariable(.init(name: accumulatedSymbolString)))
                        fields[targetFieldIndex].nodes.append(node)
                    }
                }
                
                accumulatedSymbolString = ""
                stringIndex += 1
            case
                
                // these are delimiters for a possible function
                Symbol.StringRepresentation.ambiguousDashString,
                Symbol.StringRepresentation.ambiguousPercentString,
                Symbol.StringRepresentation.ambiguousFactorialString,
                Symbol.StringRepresentation.ambiguousEEString,
                Symbol.StringRepresentation.equalsString,
                Symbol.StringRepresentation.divideString,
                Symbol.StringRepresentation.multiplyString,
                Symbol.StringRepresentation.addString,
                Symbol.StringRepresentation.subtractString,
                Symbol.StringRepresentation.negativeString,
                Symbol.StringRepresentation.explicitMultiplyString,
                Symbol.StringRepresentation.leftParenthesisChar:
                
                if let symbol = Symbol.StringRepresentation.stringToSymbol[accumulatedSymbolString] {
                    var node = Node(symbol: symbol)
                    
                    for _ in 0 ..< symbol.fieldsCount {
                        node.fields.append(NodeField())
                    }
                    
                    fields[targetFieldIndex].nodes.append(node)
                    accumulatedSymbolString = ""
                    stringIndex += 1 // add one first to skip the left parenthesis
                    
                    if char == Symbol.StringRepresentation.leftParenthesisChar {
                        // call `importFromString` on the last node
                        try fields[targetFieldIndex].nodes[fields[targetFieldIndex].nodes.count - 1].importFromString(string: string, stringIndex: &stringIndex, startParenthesesBalance: 1, context: context)
                    }
                    
                } else {
                    // symbol should always exist
                    if let symbol = Symbol.StringRepresentation.stringToSymbol[char] {
                        if symbol.fieldsCount == 0 {
                            let node = Node(symbol: symbol)
                            fields[targetFieldIndex].nodes.append(node)
                            
                            accumulatedSymbolString = ""
                        }
                        
                        if char == Symbol.StringRepresentation.leftParenthesisChar {
                            parenthesesBalance += 1
                        }
                        
                        stringIndex += 1
                    } else {
                        throw ImportError.internalError(char)
                    }
                }
                    
            case Symbol.StringRepresentation.rightParenthesisChar:
                parenthesesBalance -= 1
                stringIndex += 1
                
                if parenthesesBalance == 0 {
                    return
                }
                
                accumulatedSymbolString += char
            case Symbol.StringRepresentation.commaChar:
                accumulatedSymbolString = ""
                stringIndex += 1
                
                if targetFieldIndex < fields.count - 1 {
                    // increase the target field index
                    targetFieldIndex += 1
                } else {
                    // otherwise, just add the comma
                    let node = Node(symbol: .comma)
                    fields[targetFieldIndex].nodes.append(node)
                }
            case
                Symbol.StringRepresentation.ambiguousPowOperatorChar,
                Symbol.StringRepresentation.ambiguousPowWithFieldChar:
                
                let nextIndex = stringIndex + 1
                if nextIndex < string.count, string[nextIndex] == Symbol.StringRepresentation.leftParenthesisChar {
                    let node = Node(symbol: .ambiguousPowWithField) {}
                    fields[targetFieldIndex].nodes.append(node)
                    
                    accumulatedSymbolString = ""
                    stringIndex += 2 // skip the ^ symbol and also the (
                    
                    try fields[targetFieldIndex].nodes[fields[targetFieldIndex].nodes.count - 1].importFromString(string: string, stringIndex: &stringIndex, startParenthesesBalance: 1, context: context)
                } else {
                    let node = Node(symbol: .ambiguousPowOperator)
                    fields[targetFieldIndex].nodes.append(node)
                    
                    accumulatedSymbolString = ""
                    stringIndex += 1
                }
                
            default:
                accumulatedSymbolString += char
                
                if let symbol = Symbol.StringRepresentation.stringToSymbol[accumulatedSymbolString] {
                    switch symbol {
                    case .runtimeArgument:
                        // get the argument index
                        let nextIndex = stringIndex + 1
                        if let result = string.scanForInteger(startingIndex: nextIndex, right: true) {
                            let node = Node(symbol: .runtimeArgument(index: result.int))
                            fields[targetFieldIndex].nodes.append(node)
                            
                            accumulatedSymbolString = ""
                            
                            // skip forward to after the arg
                            stringIndex += result.count + 1
                            
                        } else {
                            throw ImportError.expectedIntAfterArgument
                        }
                    default:
                        
                        // it's a operator, number, etc (no fields)
                        // for symbols with fields, it's handled in `leftParenthesisChar`
                        if symbol.fieldsCount == 0 {
                            let node = Node(symbol: symbol)
                            fields[targetFieldIndex].nodes.append(node)
                            
                            accumulatedSymbolString = ""
                        }
                        
                        stringIndex += 1
                    }
                    
                } else {
                    stringIndex += 1
                }
            }
        }
        
        // eval any last remaining partial functions
        if let symbol = Symbol.StringRepresentation.stringToSymbol[accumulatedSymbolString] {
            var node = Node(symbol: symbol)
            
            for _ in 0 ..< symbol.fieldsCount {
                node.fields.append(NodeField())
            }
            
            fields[targetFieldIndex].nodes.append(node)
        } else {
            // fallback, just add everything as single variables
            // this happens when typing on a field
            let characters = Array(accumulatedSymbolString)
            let nodes = characters.map {
                Node(symbol: .runtimeVariable(.init(name: "\($0)")))
            }
            
            fields[targetFieldIndex].nodes += nodes
        }
    }
}
