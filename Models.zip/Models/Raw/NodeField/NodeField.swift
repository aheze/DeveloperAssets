//
//  NodeField.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 3/23/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

// a collection of nodes.
public struct NodeField: Identifiable, Codable, Hashable, Equatable {
    public var id = UUID().uuidString
    public var nodes = [Node]()

    public init(nodes: [Node] = [Node]()) {
        self.nodes = nodes
    }

    public func hash(into hasher: inout Hasher) {
        hasher.combine(id)
        hasher.combine(nodes)
    }

//    public static func == (lhs: NodeField, rhs: NodeField) -> Bool {
//        lhs.id == rhs.id && lhs.nodes == rhs.nodes
//    }
}

extension NodeField {
    @NodeFieldBuilder static var test1: NodeField {
        Node(symbol: .sqrt) {
            Node(symbol: ._2)
            Node(symbol: ._5)
        }
        Node(symbol: .add)
        Node(symbol: .ln) {
            Node(symbol: .constant(.e))
        }
        Node(symbol: .add)
        Node(symbol: .fraction) {
            Node(symbol: ._1)
        } fieldB: {
            Node(symbol: ._2)
        }
        Node(symbol: .multiply)
        Node(symbol: ._1)
        Node(symbol: ._2)
        Node(symbol: ._3)
        Node(symbol: ._4)
        Node(symbol: .add)
        Node(symbol: ._4)
        Node(symbol: .ambiguousPowWithField) {
            Node(symbol: ._2)
        }
        Node(symbol: .sin) {
            Node(symbol: .constant(.pi))
        }
    }

//    @NodeFieldBuilder static var test1: NodeField {
//        Node(symbol: .sqrt) {
//            Node(symbol: .sqrt) {
//                Node(symbol: .sqrt) {
//                    Node(symbol: ._1)
//                    Node(symbol: ._6)
//                }
//            }
//        }
//        Node(symbol: .add)
//        Node(symbol: .fraction) {
//            Node(symbol: .constant(.e))
//        } fieldB: {
//            Node(symbol: .constant(.pi))
//        }
//        Node(symbol: .add)
//        Node(symbol: ._2)
//        Node(symbol: .add)
//        Node(symbol: .sin) {
//            Node(symbol: .constant(.pi))
//            Node(symbol: .add)
//            Node(symbol: .sqrt) {
//                Node(symbol: ._6)
//                Node(symbol: ._5)
//                Node(symbol: ._4)
//                Node(symbol: .ambiguousPowWithField) {
//                    Node(symbol: ._2)
//                    Node(symbol: .add)
//                    Node(symbol: ._3)
//                    Node(symbol: .ambiguousPowWithField) {
//                        Node(symbol: ._2)
//                        Node(symbol: .ambiguousPowWithField) {
//                            Node(symbol: ._2)
//                            Node(symbol: .ambiguousPowWithField) {
//                                Node(symbol: ._2)
//                            }
//                        }
//                    }
//                }
//            }
//            Node(symbol: .add)
//            Node(symbol: ._5)
//        }
//    }

    @NodeFieldBuilder static var testPlainPow: NodeField {
        Node(symbol: .ambiguousDash)
        Node(symbol: ._1)
        Node(symbol: .ambiguousPowOperator)
        Node(symbol: ._2)
        Node(symbol: .leftParenthesis)
        Node(symbol: .ambiguousDash)
        Node(symbol: ._1)
        Node(symbol: .rightParenthesis)
        Node(symbol: .ambiguousPowOperator)
        Node(symbol: ._2)
        Node(symbol: .multiply)
        Node(symbol: ._4)
    }

    @NodeFieldBuilder static var testNested: NodeField {
        Node(symbol: .sqrt) {
            Node(symbol: .sqrt) {
                Node(symbol: .sqrt) {
                    Node(symbol: .sqrt) {
                        Node(symbol: .sqrt) {
                            Node(symbol: ._5)
                        }
                    }
                }
            }
        }
        Node(symbol: .add)
        Node(symbol: .sin) {
            Node(symbol: ._5)
            Node(symbol: .add)
            Node(symbol: .sqrt) {
                Node(symbol: ._6)
                Node(symbol: ._5)
                Node(symbol: .ambiguousPowWithField) {
                    Node(symbol: ._2)
                    Node(symbol: .add)
                    Node(symbol: ._3)
                }
            }
            Node(symbol: .add)
            Node(symbol: ._5)
        }
    }

    @NodeFieldBuilder static var testPlainPowWithParentheses: NodeField {
        Node(symbol: ._5)
        Node(symbol: .add)
        Node(symbol: ._6)
        Node(symbol: ._5)
        Node(symbol: .ambiguousPowOperator)
        Node(symbol: .leftParenthesis)
        Node(symbol: ._2)
        Node(symbol: .add)
        Node(symbol: ._3)
        Node(symbol: .rightParenthesis)
        Node(symbol: .add)
        Node(symbol: ._5)
    }

    @NodeFieldBuilder static var testRaisedPow: NodeField {
        Node(symbol: ._5)
        Node(symbol: .add)
        Node(symbol: ._6)
        Node(symbol: ._5)
        Node(symbol: .ambiguousPowWithField) {
            Node(symbol: ._2)
            Node(symbol: .add)
            Node(symbol: ._3)
        }
        Node(symbol: .add)
        Node(symbol: ._5)
    }

    @NodeFieldBuilder static var testEE: NodeField {
        Node(symbol: ._5)
        Node(symbol: .add)
        Node(symbol: ._6)
        Node(symbol: ._5)
        Node(symbol: .ambiguousEE)
        Node(symbol: .ambiguousDash)
        Node(symbol: ._2)
        Node(symbol: .add)
        Node(symbol: ._3)
        Node(symbol: .add)
        Node(symbol: ._5)
    }

    @NodeFieldBuilder static var testSmartPercent: NodeField {
        Node(symbol: ._5)
        Node(symbol: .add)
        Node(symbol: ._2)
        Node(symbol: ._0)
        Node(symbol: .ambiguousPercent)
        Node(symbol: .add)
        Node(symbol: ._5)
        Node(symbol: .multiply)
        Node(symbol: ._2)
        Node(symbol: ._0)
        Node(symbol: .ambiguousPercent)
    }

    @NodeFieldBuilder static var testSummation: NodeField {
        Node(symbol: .summation) {
            Node(symbol: .runtimeVariable(Symbol.VariableContext(name: "n")))
            Node(symbol: .equals)
            Node(symbol: .simpleValue(0))
        } fieldB: {
            Node(symbol: .simpleValue(10))
        } fieldC: {
            Node(symbol: .simpleValue(0.1))
//            Node(symbol: .variable(Symbol.VariableContext(name: "n")))
        }
    }

    @NodeFieldBuilder static var testProduct: NodeField {
        Node(symbol: .summation) {
            Node(symbol: .runtimeVariable(Symbol.VariableContext(name: "n")))
            Node(symbol: .equals)
            Node(symbol: .simpleValue(0))
        } fieldB: {
            Node(symbol: .simpleValue(2))
        } fieldC: {
            Node(symbol: .simpleValue(5))
        }
    }
}
