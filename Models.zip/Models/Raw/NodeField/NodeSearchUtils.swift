//
//  NodeSearchUtils.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 4/4/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

// MARK: - Basic tree search

extension Node {
    func getChildNode(id: String) -> Node? {
        if self.id == id {
            return self
        }

        for field in fields {
            for node in field.nodes {
                if let childNode = node.getChildNode(id: id) {
                    return childNode
                }
            }
        }

        return nil
    }

    func getChildField(id: String) -> NodeField? {
        for field in fields {
            if let childField = field.getChildField(id: id) {
                return childField
            }
        }

        return nil
    }
}

extension NodeField {
    func getChildField(id: String) -> NodeField? {
        if self.id == id {
            return self
        }

        for node in nodes {
            for field in node.fields {
                if let childField = field.getChildField(id: id) {
                    return childField
                }
            }
        }

        return nil
    }

    mutating func getChildFieldReference(id: String, block: (inout NodeField) -> Void) {
        if self.id == id {
            block(&self)
        }

        for nodeIndex in nodes.indices {
            for fieldIndex in nodes[nodeIndex].fields.indices {
                nodes[nodeIndex].fields[fieldIndex].getChildFieldReference(id: id, block: block)
            }
        }
    }

    func getChildNode(id: String) -> Node? {
        for node in nodes {
            if let childNode = node.getChildNode(id: id) {
                return childNode
            }
        }

        return nil
    }

    func getEqualOrHigherLevelFieldIDs(id: String) -> [String] {
        [id] + getHigherLevelFieldIDs(id: id)
    }
    
    // get ID's of fields that are at a higher level than this one
    // call this on the root field
    func getHigherLevelFieldIDs(id: String) -> [String] {
        return getHigherLevelFieldIDsRaw(fieldID: id, accumulated: [])
    }

    func getHigherLevelFieldIDsRaw(fieldID: String, accumulated: [String]) -> [String] {
        var accumulated = accumulated

        if
            let parentNode = getParentNode(of: fieldID),
            let parentField = getParentField(of: parentNode.id)
        {
            accumulated.append(parentField.id)
            accumulated += parentField.getHigherLevelFieldIDsRaw(fieldID: parentField.id, accumulated: accumulated)
        }

        return accumulated
    }
}

// MARK: - Call these functions on the root node field

extension NodeField {
    func getParentNode(of fieldID: String) -> Node? {
        return getChildNode(containing: fieldID)
    }

    func getParentField(of nodeID: String) -> NodeField? {
        return getChildField(containing: nodeID)
    }

    func getChildNode(containing fieldID: String) -> Node? {
        for node in nodes {
            if let childNode = node.getChildNode(containing: fieldID) {
                return childNode
            }
        }

        return nil
    }

    func getChildField(containing nodeID: String) -> NodeField? {
        for node in nodes {
            if node.id == nodeID {
                return self
            }

            for field in node.fields {
                if let childField = field.getChildField(containing: nodeID) {
                    return childField
                }
            }
        }

        return nil
    }

    // get the highest level node
    func getNodeInRoot(containing fieldID: String) -> Node? {
        for node in nodes {
            if node.getChildField(id: fieldID) != nil {
                return node
            }
        }

        return nil
    }
}

extension Node {
    func getChildNode(containing fieldID: String) -> Node? {
        for field in fields {
            if field.id == fieldID {
                return self
            }

            for node in field.nodes {
                if let childNode = node.getChildNode(containing: fieldID) {
                    return childNode
                }
            }
        }

        return nil
    }
}
