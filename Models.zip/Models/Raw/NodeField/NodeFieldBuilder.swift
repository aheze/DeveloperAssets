//
//  NodeFieldBuilder.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 4/3/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

@resultBuilder public enum NodeFieldBuilder {
    public static func buildOptional(_ component: Node?) -> NodeField {
        if let component {
            return NodeField(nodes: [component])
        } else {
            return NodeField(nodes: [])
        }
    }

    public static func buildBlock(_ parts: Node...) -> NodeField {
        return NodeField(nodes: parts)
    }

    public static func buildEither(first component: Node) -> NodeField {
        return NodeField(nodes: [component])
    }

    public static func buildEither(second component: Node) -> NodeField {
        return NodeField(nodes: [component])
    }

    public static func buildArray(_ components: [Node]) -> NodeField {
        return NodeField(nodes: components)
    }
}
