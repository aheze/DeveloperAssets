//
//  Node.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 3/23/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

public struct Node: Identifiable, Hashable, Equatable, Codable {
    public var id = UUID().uuidString
    public var symbol: Symbol
    public var fields = [NodeField]()

    public init(symbol: Symbol, fields: [NodeField] = []) {
        self.symbol = symbol
        self.fields = fields
    }

    public func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }

//    public static func == (lhs: Node, rhs: Node) -> Bool {
//        lhs.id == rhs.id && lhs.symbol == rhs.symbol && lhs.fields == rhs.fields
//    }
}

public extension Node {
    init(symbol: Symbol, @NodeFieldBuilder fieldA: () -> NodeField) {
        self.symbol = symbol
        self.fields = [fieldA()]
    }

    init(symbol: Symbol, @NodeFieldBuilder fieldA: () -> NodeField, @NodeFieldBuilder fieldB: () -> NodeField) {
        self.symbol = symbol
        self.fields = [fieldA(), fieldB()]
    }

    init(symbol: Symbol, @NodeFieldBuilder fieldA: () -> NodeField, @NodeFieldBuilder fieldB: () -> NodeField, @NodeFieldBuilder fieldC: () -> NodeField) {
        self.symbol = symbol
        self.fields = [fieldA(), fieldB(), fieldC()]
    }
}
