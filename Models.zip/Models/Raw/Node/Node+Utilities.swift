//
//  Node+Utilities.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 3/26/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

extension Node {
    func getChildField(index: Int) throws -> NodeField {
        if index < 0 {
            throw EvaluateError.internalErrorOutOfBoundsIndex
        } else if index >= fields.count {
            throw EvaluateError.internalErrorOutOfBoundsIndex
        }
        return fields[index]
    }

    func getArgumentsForAggregate(context: EvaluateContext) throws -> (lowerBound: Int, upperBound: Int, variableName: String) {
        let arg0 = try getChildField(index: 0)

        let analysis = arg0.analyzeContents()
        // get the variable name (e.g. "n") and its corresponding NodeField
        guard let assignment = analysis.variableAssignments.first else {
            throw EvaluateError.missingVariableAssignmentInSum
        }
        let lowerBoundRaw = try assignment.value.evaluateToDouble(context: context)
        guard lowerBoundRaw < Double(Int.max) else {
            throw EvaluateError.intIsTooBig
        }
        let lowerBound = Int(lowerBoundRaw)

        // e.g. 5
        let upperBoundRaw = try evaluateChildFieldToDouble(index: 1, context: context)
        guard upperBoundRaw < Double(Int.max) else {
            throw EvaluateError.intIsTooBig
        }

        let upperBound = Int(upperBoundRaw)

        return (lowerBound, upperBound, assignment.key)
    }
    
//    mutating func appendToLastField(node: Node) {
//        if fields.isEmpty {
//            fields.append(NodeField(nodes: [node]))
//        } else {
//            fields[fields.count - 1].nodes.append(node)
//        }
//    }
//    
//    func getLastNodeInAllFields() -> Node? {
//        fields.last?.nodes.last
//    }
}
