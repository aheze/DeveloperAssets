//
//  NodeField+Representation.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 3/24/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

extension NodeField: CustomDebugStringConvertible {
    public var debugDescription: String {
        return stringRepresentation
    }
}

extension NodeField {
    var stringRepresentation: Representation {
        return nodes.map { $0.stringRepresentation }.joined(separator: "")
    }
}

extension Array where Element == NodeField {
    var stringRepresentation: String {
        return map { $0.stringRepresentation }.joined(separator: ",")
    }
}
