//
//  Representation.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 3/27/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

typealias Representation = String

