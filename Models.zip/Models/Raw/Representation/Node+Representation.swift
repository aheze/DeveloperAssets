//
//  Node+Representation.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 3/24/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

extension Node {
    func functionStringRepresentation(title: String, expectedFieldsCount: Int) -> String {
        guard fields.count == expectedFieldsCount else {
            return "\(title)[InvalidFieldsCountError-Expected\(expectedFieldsCount)-Got\(fields.count)](\(fields.stringRepresentation))"
        }
        return "\(title)(\(fields.stringRepresentation))"
    }
}

extension Node: CustomDebugStringConvertible {
    public var debugDescription: String {
        return stringRepresentation
    }
}

extension Node {
    var stringRepresentation: Representation {
        if fields.isEmpty {
            return symbol.stringRepresentation
        } else {
            return "\(symbol.stringRepresentation)(\(fields.stringRepresentation))"
        }
    }
}

// switch symbol {
// case .constant(let name, let value):
//    return name
// case .variable(let variableContext):
//    return variableContext.name
// case .runtimeFunction(let functionContext):
//    return functionContext.name
// case .runtimeArgument(let index):
//    return "arguments[\(index)]"
// case .comma:
//    return ","
// case ._0:
//    return "0"
// case ._1:
//    return "1"
// case ._2:
//    return "2"
// case ._3:
//    return "3"
// case ._4:
//    return "4"
// case ._5:
//    return "5"
// case ._6:
//    return "6"
// case ._7:
//    return "7"
// case ._8:
//    return "8"
// case ._9:
//    return "9"
// case .period:
//    return "."
// case .divide:
//    return "/"
// case .cross:
//    return "*"
// case .plus:
//    return "+"
// case .dash:
//    return "-"
// case .equals:
//    return "="
// case .percent:
//    return "%"
// case .factorial:
//    return "!"
// case .ee:
//    return "EE"
// case .leftParenthesis:
//    return "("
// case .rightParenthesis:
//    return ")"
// case .sqrt:
//    return functionStringRepresentation(title: "sqrt", expectedFieldsCount: 1)
// case .nroot:
//    return functionStringRepresentation(title: "nroot", expectedFieldsCount: 2)
// case .powOperator:
//    return "^"
// case .powWithField:
//    return functionStringRepresentation(title: "^[WithField]", expectedFieldsCount: 1)
// case .ln:
//    return functionStringRepresentation(title: "ln", expectedFieldsCount: 1)
// case .log:
//    return functionStringRepresentation(title: "log", expectedFieldsCount: 1)
// case .loga:
//    return functionStringRepresentation(title: "loga", expectedFieldsCount: 2)
// case .abs:
//    return functionStringRepresentation(title: "abs", expectedFieldsCount: 1)
// case .floor:
//    return functionStringRepresentation(title: "floor", expectedFieldsCount: 1)
// case .ceil:
//    return functionStringRepresentation(title: "ceil", expectedFieldsCount: 1)
// case .round:
//    return functionStringRepresentation(title: "round", expectedFieldsCount: 1)
// case .sign:
//    return functionStringRepresentation(title: "sign", expectedFieldsCount: 1)
// case .mod:
//    return functionStringRepresentation(title: "mod", expectedFieldsCount: 2)
// case .npr:
//    return functionStringRepresentation(title: "npr", expectedFieldsCount: 2)
// case .ncr:
//    return functionStringRepresentation(title: "ncr", expectedFieldsCount: 2)
// case .numericalDifferentiation:
//    return functionStringRepresentation(title: "diff", expectedFieldsCount: 2)
// case .numericalIntegration:
//    return functionStringRepresentation(title: "int", expectedFieldsCount: 3)
// case .summation:
//    return functionStringRepresentation(title: "summation", expectedFieldsCount: 3)
// case .product:
//    return functionStringRepresentation(title: "product", expectedFieldsCount: 3)
// case .fraction:
//    return functionStringRepresentation(title: "fraction", expectedFieldsCount: 2)
// case .sin:
//    return functionStringRepresentation(title: "sin", expectedFieldsCount: 1)
// case .cos:
//    return functionStringRepresentation(title: "cos", expectedFieldsCount: 1)
// case .tan:
//    return functionStringRepresentation(title: "tan", expectedFieldsCount: 1)
// case .asin:
//    return functionStringRepresentation(title: "asin", expectedFieldsCount: 1)
// case .acos:
//    return functionStringRepresentation(title: "acos", expectedFieldsCount: 1)
// case .atan:
//    return functionStringRepresentation(title: "atan", expectedFieldsCount: 1)
// case .csc:
//    return functionStringRepresentation(title: "csc", expectedFieldsCount: 1)
// case .sec:
//    return functionStringRepresentation(title: "sec", expectedFieldsCount: 1)
// case .cot:
//    return functionStringRepresentation(title: "cot", expectedFieldsCount: 1)
// case .acsc:
//    return functionStringRepresentation(title: "acsc", expectedFieldsCount: 1)
// case .asec:
//    return functionStringRepresentation(title: "asec", expectedFieldsCount: 1)
// case .acot:
//    return functionStringRepresentation(title: "acot", expectedFieldsCount: 1)
// case .sinh:
//    return functionStringRepresentation(title: "sinh", expectedFieldsCount: 1)
// case .cosh:
//    return functionStringRepresentation(title: "cosh", expectedFieldsCount: 1)
// case .tanh:
//    return functionStringRepresentation(title: "tanh", expectedFieldsCount: 1)
// case .asinh:
//    return functionStringRepresentation(title: "asinh", expectedFieldsCount: 1)
// case .acosh:
//    return functionStringRepresentation(title: "acosh", expectedFieldsCount: 1)
// case .atanh:
//    return functionStringRepresentation(title: "atanh", expectedFieldsCount: 1)
// case .csch:
//    return functionStringRepresentation(title: "csch", expectedFieldsCount: 1)
// case .sech:
//    return functionStringRepresentation(title: "sech", expectedFieldsCount: 1)
// case .coth:
//    return functionStringRepresentation(title: "coth", expectedFieldsCount: 1)
// case .acsch:
//    return functionStringRepresentation(title: "acsch", expectedFieldsCount: 1)
// case .asech:
//    return functionStringRepresentation(title: "asech", expectedFieldsCount: 1)
// case .acoth:
//    return functionStringRepresentation(title: "acoth", expectedFieldsCount: 1)
// case .matrix(let matrixProperties):
//    return "matrix(\(matrixProperties.rowsCount),\(matrixProperties.colsCount),\(fields.stringRepresentation))"
// case .matrixRREF:
//    return functionStringRepresentation(title: "mREEF", expectedFieldsCount: 1)
// case .matrixDeterminant:
//    return functionStringRepresentation(title: "mDet", expectedFieldsCount: 1)
// case .matrixTrace:
//    return functionStringRepresentation(title: "mTrace", expectedFieldsCount: 1)
// case .matrixInverse:
//    return functionStringRepresentation(title: "mInverse", expectedFieldsCount: 1)
// case .matrixTranspose:
//    return functionStringRepresentation(title: "mTranspose", expectedFieldsCount: 1)
// case .unambiguousPower:
//    return functionStringRepresentation(title: "pow", expectedFieldsCount: 2)
// case .unambiguousEE:
//    return functionStringRepresentation(title: "EE", expectedFieldsCount: 2)
// case .unambiguousPercent:
//    return functionStringRepresentation(title: "percent", expectedFieldsCount: 1)
// case .unambiguousFactorial:
//    return functionStringRepresentation(title: "factorial", expectedFieldsCount: 1)
// case .unambiguousSubtract:
//    return "-"
// case .unambiguousNegative:
//    return "_"
// case .explicitMultiplication:
//    return "*"
// case .simpleValue(let number):
//    return "\(number)"
// }
