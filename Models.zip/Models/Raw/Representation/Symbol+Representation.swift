//
//  Symbol+String.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 4/6/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

extension Symbol {
    enum StringRepresentation {
        // static var variable(VariableContext)String
        // static var function(FunctionContext)String
        // static var argument(index: Int)String

        // static var simpleValue(Double)String
        // static var constant(name: String, value: Double)String

        static var delimiter = "\""
        static var _0String = "0"
        static var _1String = "1"
        static var _2String = "2"
        static var _3String = "3"
        static var _4String = "4"
        static var _5String = "5"
        static var _6String = "6"
        static var _7String = "7"
        static var _8String = "8"
        static var _9String = "9"
        static var periodString = "."
        static var runtimeArgumentString = "arg"
        static var ambiguousDashString = "-"
        static var ambiguousPercentString = "%"
        static var ambiguousFactorialString = "!"
        static var ambiguousEEString = "ᴇ"
        static var ambiguousPowOperatorChar = "^"
        static var ambiguousPowWithFieldChar = "^"
        static var leftParenthesisChar = "("
        static var rightParenthesisChar = ")"
        static var equalsString = "="
        static var commaChar = ","
        static var fractionString = "frac"
        static var divideString = "/"
        static var multiplyString = "*"
        static var addString = "+"
        static var sqrtString = "sqrt"
        static var nrootString = "nroot"
        static var lnString = "ln"
        static var logString = "log"
        static var logaString = "loga"
        static var absString = "abs"
        static var floorString = "floor"
        static var ceilString = "ceil"
        static var roundString = "round"
        static var signString = "sign"
        static var modString = "mod"
        static var inverseString = "inverse"
        static var nprString = "npr"
        static var ncrString = "ncr"
        static var numericalDifferentiationString = "numericalDifferentiation"
        static var numericalIntegrationString = "numericalIntegration"
        static var summationString = "summation"
        static var productString = "product"
        static var sinString = "sin"
        static var cosString = "cos"
        static var tanString = "tan"
        static var asinString = "asin"
        static var acosString = "acos"
        static var atanString = "atan"
        static var cscString = "csc"
        static var secString = "sec"
        static var cotString = "cot"
        static var acscString = "acsc"
        static var asecString = "asec"
        static var acotString = "acot"
        static var sinhString = "sinh"
        static var coshString = "cosh"
        static var tanhString = "tanh"
        static var asinhString = "asinh"
        static var acoshString = "acosh"
        static var atanhString = "atanh"
        static var cschString = "csch"
        static var sechString = "sech"
        static var cothString = "coth"
        static var acschString = "acsch"
        static var asechString = "asech"
        static var acothString = "acoth"
        static var matrixString = "matrix"
        static var matrixRREFString = "rref"
        static var matrixDeterminantString = "det"
        static var matrixTraceString = "trace"
        static var matrixTransposeString = "transpose"
        static var powerString = "power"
        static var enterExponentString = "ee"
        static var percentString = "percent"
        static var factorialString = "factorial"
        static var subtractString = "-"
        static var negativeString = "-"
        static var explicitMultiplyString = "*"

        static let allCases: [String] = [
            StringRepresentation._0String,
            StringRepresentation._1String,
            StringRepresentation._2String,
            StringRepresentation._3String,
            StringRepresentation._4String,
            StringRepresentation._5String,
            StringRepresentation._6String,
            StringRepresentation._7String,
            StringRepresentation._8String,
            StringRepresentation._9String,
            StringRepresentation.periodString,
            StringRepresentation.runtimeArgumentString,
            StringRepresentation.ambiguousDashString,
            StringRepresentation.ambiguousPercentString,
            StringRepresentation.ambiguousFactorialString,
            StringRepresentation.ambiguousEEString,
            StringRepresentation.ambiguousPowOperatorChar,
            StringRepresentation.ambiguousPowWithFieldChar,
            StringRepresentation.leftParenthesisChar,
            StringRepresentation.rightParenthesisChar,
            StringRepresentation.equalsString,
            StringRepresentation.commaChar,
            StringRepresentation.fractionString,
            StringRepresentation.divideString,
            StringRepresentation.multiplyString,
            StringRepresentation.addString,
            StringRepresentation.sqrtString,
            StringRepresentation.nrootString,
            StringRepresentation.lnString,
            StringRepresentation.logString,
            StringRepresentation.logaString,
            StringRepresentation.absString,
            StringRepresentation.floorString,
            StringRepresentation.ceilString,
            StringRepresentation.roundString,
            StringRepresentation.signString,
            StringRepresentation.modString,
            StringRepresentation.inverseString,
            StringRepresentation.nprString,
            StringRepresentation.ncrString,
            StringRepresentation.numericalDifferentiationString,
            StringRepresentation.numericalIntegrationString,
            StringRepresentation.summationString,
            StringRepresentation.productString,
            StringRepresentation.sinString,
            StringRepresentation.cosString,
            StringRepresentation.tanString,
            StringRepresentation.asinString,
            StringRepresentation.acosString,
            StringRepresentation.atanString,
            StringRepresentation.cscString,
            StringRepresentation.secString,
            StringRepresentation.cotString,
            StringRepresentation.acscString,
            StringRepresentation.asecString,
            StringRepresentation.acotString,
            StringRepresentation.sinhString,
            StringRepresentation.coshString,
            StringRepresentation.tanhString,
            StringRepresentation.asinhString,
            StringRepresentation.acoshString,
            StringRepresentation.atanhString,
            StringRepresentation.cschString,
            StringRepresentation.sechString,
            StringRepresentation.cothString,
            StringRepresentation.acschString,
            StringRepresentation.asechString,
            StringRepresentation.acothString,
            StringRepresentation.matrixString,
            StringRepresentation.matrixRREFString,
            StringRepresentation.matrixDeterminantString,
            StringRepresentation.matrixTraceString,
            StringRepresentation.matrixTransposeString,
            StringRepresentation.powerString,
            StringRepresentation.enterExponentString,
            StringRepresentation.percentString,
            StringRepresentation.factorialString,
            StringRepresentation.subtractString,
            StringRepresentation.negativeString,
            StringRepresentation.explicitMultiplyString,
        ]

        // returns a symbol based on the string.
        // Note: the symbol still needs to be populated!
        // What's returned here is just a template.
        // to prevent duplicate keys, some keys are removed and need further processing.
        static let stringToSymbol: [String: Symbol] = [
            StringRepresentation._0String: ._0,
            StringRepresentation._1String: ._1,
            StringRepresentation._2String: ._2,
            StringRepresentation._3String: ._3,
            StringRepresentation._4String: ._4,
            StringRepresentation._5String: ._5,
            StringRepresentation._6String: ._6,
            StringRepresentation._7String: ._7,
            StringRepresentation._8String: ._8,
            StringRepresentation._9String: ._9,
            StringRepresentation.periodString: .period,
            StringRepresentation.runtimeArgumentString: .runtimeArgument(index: 0),
            StringRepresentation.ambiguousDashString: .ambiguousDash,
            StringRepresentation.ambiguousPercentString: .ambiguousPercent,
            StringRepresentation.ambiguousFactorialString: .ambiguousFactorial,
            StringRepresentation.ambiguousEEString: .ambiguousEE,
            StringRepresentation.ambiguousPowOperatorChar: .ambiguousPowOperator,
//            StringRepresentation.ambiguousPowWithFieldChar: .ambiguousPowWithField,
            StringRepresentation.leftParenthesisChar: .leftParenthesis,
            StringRepresentation.rightParenthesisChar: .rightParenthesis,
            StringRepresentation.equalsString: .equals,
            StringRepresentation.commaChar: .comma,
            StringRepresentation.fractionString: .fraction,
            StringRepresentation.divideString: .divide,
            StringRepresentation.multiplyString: .multiply,
            StringRepresentation.addString: .add,
            StringRepresentation.sqrtString: .sqrt,
            StringRepresentation.nrootString: .nroot,
            StringRepresentation.lnString: .ln,
            StringRepresentation.logString: .log,
            StringRepresentation.logaString: .loga,
            StringRepresentation.absString: .abs,
            StringRepresentation.floorString: .floor,
            StringRepresentation.ceilString: .ceil,
            StringRepresentation.roundString: .round,
            StringRepresentation.signString: .sign,
            StringRepresentation.modString: .mod,
            StringRepresentation.inverseString: .inverse,
            StringRepresentation.nprString: .npr,
            StringRepresentation.ncrString: .ncr,
            StringRepresentation.numericalDifferentiationString: .numericalDifferentiation,
            StringRepresentation.numericalIntegrationString: .numericalIntegration,
            StringRepresentation.summationString: .summation,
            StringRepresentation.productString: .product,
            StringRepresentation.sinString: .sin,
            StringRepresentation.cosString: .cos,
            StringRepresentation.tanString: .tan,
            StringRepresentation.asinString: .asin,
            StringRepresentation.acosString: .acos,
            StringRepresentation.atanString: .atan,
            StringRepresentation.cscString: .csc,
            StringRepresentation.secString: .sec,
            StringRepresentation.cotString: .cot,
            StringRepresentation.acscString: .acsc,
            StringRepresentation.asecString: .asec,
            StringRepresentation.acotString: .acot,
            StringRepresentation.sinhString: .sinh,
            StringRepresentation.coshString: .cosh,
            StringRepresentation.tanhString: .tanh,
            StringRepresentation.asinhString: .asinh,
            StringRepresentation.acoshString: .acosh,
            StringRepresentation.atanhString: .atanh,
            StringRepresentation.cschString: .csch,
            StringRepresentation.sechString: .sech,
            StringRepresentation.cothString: .coth,
            StringRepresentation.acschString: .acsch,
            StringRepresentation.asechString: .asech,
            StringRepresentation.acothString: .acoth,
            StringRepresentation.matrixString: .matrix(MatrixProperties()),
            StringRepresentation.matrixRREFString: .matrixRREF,
            StringRepresentation.matrixDeterminantString: .matrixDeterminant,
            StringRepresentation.matrixTraceString: .matrixTrace,
            StringRepresentation.matrixTransposeString: .matrixTranspose,
            StringRepresentation.powerString: .power,
            StringRepresentation.enterExponentString: .enterExponent,
            StringRepresentation.percentString: .percent,
            StringRepresentation.factorialString: .factorial,
//            StringRepresentation.subtractString: .subtract,
//            StringRepresentation.negativeString: .negative,
//            StringRepresentation.explicitMultiplyString: .explicitMultiply,
        ]
    }
}

extension Symbol {
    var stringRepresentation: Representation {
        switch self {
        case ._0:
            return Symbol.StringRepresentation._0String
        case ._1:
            return Symbol.StringRepresentation._1String
        case ._2:
            return Symbol.StringRepresentation._2String
        case ._3:
            return Symbol.StringRepresentation._3String
        case ._4:
            return Symbol.StringRepresentation._4String
        case ._5:
            return Symbol.StringRepresentation._5String
        case ._6:
            return Symbol.StringRepresentation._6String
        case ._7:
            return Symbol.StringRepresentation._7String
        case ._8:
            return Symbol.StringRepresentation._8String
        case ._9:
            return Symbol.StringRepresentation._9String
        case .period:
            return Symbol.StringRepresentation.periodString
        case .runtimeVariable(let variableContext):
            return "\(Symbol.StringRepresentation.delimiter)\(variableContext.name)\(Symbol.StringRepresentation.delimiter)" // Assuming a variable context with a 'name' property
        case .runtimeFunction(let functionContext):
            return functionContext.name // Assuming a function context with a 'name' property
        case .runtimeArgument(let index):

            // format: "arg0"
            return "\(Symbol.StringRepresentation.runtimeArgumentString)\(index)"
        case .ambiguousDash:
            return Symbol.StringRepresentation.ambiguousDashString
        case .ambiguousPercent:
            return Symbol.StringRepresentation.ambiguousPercentString
        case .ambiguousFactorial:
            return Symbol.StringRepresentation.ambiguousFactorialString
        case .ambiguousEE:
            return Symbol.StringRepresentation.ambiguousEEString
        case .ambiguousPowOperator:
            return Symbol.StringRepresentation.ambiguousPowOperatorChar
        case .ambiguousPowWithField:
            return Symbol.StringRepresentation.ambiguousPowWithFieldChar
        case .simpleValue(let double):
            return "\(double)"
        case .constant(let constant):
            return "\(Symbol.StringRepresentation.delimiter)\(constant.name)\(Symbol.StringRepresentation.delimiter)" // Only returning the name of the constant
        case .leftParenthesis:
            return Symbol.StringRepresentation.leftParenthesisChar
        case .rightParenthesis:
            return Symbol.StringRepresentation.rightParenthesisChar
        case .equals:
            return Symbol.StringRepresentation.equalsString
        case .comma:
            return Symbol.StringRepresentation.commaChar
        case .fraction:
            // node format: ((...)/(...)) (double parentheses)
            return Symbol.StringRepresentation.fractionString
        case .divide:
            return Symbol.StringRepresentation.divideString
        case .multiply:
            return Symbol.StringRepresentation.multiplyString
        case .add:
            return Symbol.StringRepresentation.addString
        case .functionStem(let kind):
            return kind.title
        case .sqrt:
            return Symbol.StringRepresentation.sqrtString
        case .nroot:
            return Symbol.StringRepresentation.nrootString
        case .ln:
            return Symbol.StringRepresentation.lnString
        case .log:
            return Symbol.StringRepresentation.logString
        case .loga:
            return Symbol.StringRepresentation.logaString
        case .abs:
            return Symbol.StringRepresentation.absString
        case .floor:
            return Symbol.StringRepresentation.floorString
        case .ceil:
            return Symbol.StringRepresentation.ceilString
        case .round:
            return Symbol.StringRepresentation.roundString
        case .sign:
            return Symbol.StringRepresentation.signString
        case .mod:
            return Symbol.StringRepresentation.modString
        case .inverse:
            return Symbol.StringRepresentation.inverseString
        case .npr:
            return Symbol.StringRepresentation.nprString
        case .ncr:
            return Symbol.StringRepresentation.ncrString
        case .numericalDifferentiation:
            return Symbol.StringRepresentation.numericalDifferentiationString
        case .numericalIntegration:
            return Symbol.StringRepresentation.numericalIntegrationString
        case .summation:
            return Symbol.StringRepresentation.summationString
        case .product:
            return Symbol.StringRepresentation.productString
        case .sin:
            return Symbol.StringRepresentation.sinString
        case .cos:
            return Symbol.StringRepresentation.cosString
        case .tan:
            return Symbol.StringRepresentation.tanString
        case .asin:
            return Symbol.StringRepresentation.asinString
        case .acos:
            return Symbol.StringRepresentation.acosString
        case .atan:
            return Symbol.StringRepresentation.atanString
        case .csc:
            return Symbol.StringRepresentation.cscString
        case .sec:
            return Symbol.StringRepresentation.secString
        case .cot:
            return Symbol.StringRepresentation.cotString
        case .acsc:
            return Symbol.StringRepresentation.acscString
        case .asec:
            return Symbol.StringRepresentation.asecString
        case .acot:
            return Symbol.StringRepresentation.acotString
        case .sinh:
            return Symbol.StringRepresentation.sinhString
        case .cosh:
            return Symbol.StringRepresentation.coshString
        case .tanh:
            return Symbol.StringRepresentation.tanhString
        case .asinh:
            return Symbol.StringRepresentation.asinhString
        case .acosh:
            return Symbol.StringRepresentation.acoshString
        case .atanh:
            return Symbol.StringRepresentation.atanhString
        case .csch:
            return Symbol.StringRepresentation.cschString
        case .sech:
            return Symbol.StringRepresentation.sechString
        case .coth:
            return Symbol.StringRepresentation.cothString
        case .acsch:
            return Symbol.StringRepresentation.acschString
        case .asech:
            return Symbol.StringRepresentation.asechString
        case .acoth:
            return Symbol.StringRepresentation.acothString
        case .matrix(let matrixProperties):
            return "\(Symbol.StringRepresentation.matrixString)\(matrixProperties.rowsCount)x\(matrixProperties.colsCount)"
        case .matrixRREF:
            return Symbol.StringRepresentation.matrixRREFString
        case .matrixDeterminant:
            return Symbol.StringRepresentation.matrixDeterminantString
        case .matrixTrace:
            return Symbol.StringRepresentation.matrixTraceString
        case .matrixTranspose:
            return Symbol.StringRepresentation.matrixTransposeString
        case .power:
            return Symbol.StringRepresentation.powerString
        case .enterExponent:
            return Symbol.StringRepresentation.enterExponentString
        case .percent:
            return Symbol.StringRepresentation.percentString
        case .factorial:
            return Symbol.StringRepresentation.factorialString
        case .subtract:
            return Symbol.StringRepresentation.subtractString
        case .negative:
            return Symbol.StringRepresentation.negativeString
        case .explicitMultiply:
            return Symbol.StringRepresentation.explicitMultiplyString
        }
    }
}
