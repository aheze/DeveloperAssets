//
//  NodeField+Analyze.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 3/26/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

extension NodeField {
    func analyzeContents() -> AnalysisResult {
        var result = AnalysisResult()

        print("analyze: \(nodes)")
        
        for index in nodes.indices {
            let node = nodes[index]

            if index > 0, nodes.count >= 3 {
                if case .equals = node.symbol {
                    print("nodes[index - 1].symbol: \(nodes[index - 1].symbol)")
                    if case .runtimeVariable(let variableContext) = nodes[index - 1].symbol {
                        let field = NodeField(nodes: Array(nodes[index + 1 ..< nodes.count]))
                        result.variableAssignments[variableContext.name] = field
                    }
                }
            }
        }

        return result
    }
}
