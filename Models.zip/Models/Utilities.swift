//
//  Utilities.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 3/31/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

extension Array {
    func chunked(into size: Int) -> [[Element]] {
        return stride(from: 0, to: count, by: size).map {
            Array(self[$0 ..< Swift.min($0 + size, count)])
        }
    }

    func stridePartition(stride: Int) -> [[Element]] {
        var result = [[Element]](repeating: [Element](), count: stride)
        for index in 0 ..< count {
            result[index % stride].append(self[index])
        }
        return result
    }
}

extension Double {
    // convert number to NodeField
    var nodeField: NodeField {
        NodeField(nodes: [Node(symbol: .simpleValue(self))])
    }
}

// from https://stackoverflow.com/a/32306142/14351818
extension StringProtocol {
    func index<S: StringProtocol>(of string: S, options: String.CompareOptions = []) -> Index? {
        range(of: string, options: options)?.lowerBound
    }
    func endIndex<S: StringProtocol>(of string: S, options: String.CompareOptions = []) -> Index? {
        range(of: string, options: options)?.upperBound
    }
    func indices<S: StringProtocol>(of string: S, options: String.CompareOptions = []) -> [Index] {
        ranges(of: string, options: options).map(\.lowerBound)
    }
    func ranges<S: StringProtocol>(of string: S, options: String.CompareOptions = []) -> [Range<Index>] {
        var result: [Range<Index>] = []
        var startIndex = self.startIndex
        while startIndex < endIndex,
            let range = self[startIndex...]
                .range(of: string, options: options) {
                result.append(range)
                startIndex = range.lowerBound < range.upperBound ? range.upperBound :
                    index(range.lowerBound, offsetBy: 1, limitedBy: endIndex) ?? endIndex
        }
        return result
    }
}
