//
//  Number.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 3/31/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import BigInt
import Foundation

// typealias Number = Double

//struct Number: Codable, ExpressibleByIntegerLiteral, ExpressibleByFloatLiteral {
//    var numeratorNormal: Int?
//    var denominatorNormal: Int?
//    var numeratorBig: BInt?
//    var denominatorBig: BInt?
//    
//    init(integerLiteral value: Int) {
//        numeratorNormal = value
//    }
//
//    init(floatLiteral value: Double) {
//        numeratorNormal = -1
//    }
//    
//    init?(_ string: String) {
//        numeratorNormal = -2
//    }
//    
//    init(_ int: Int) {
//        numeratorNormal = int
//    }
//    
//    var integer: Int? {
//        if let numeratorNormal {
//            if let denominatorNormal {
//                return numeratorNormal / denominatorNormal
//            } else {
//                numeratorNormal
//            }
//        }
//        
//        if let numeratorBig {
//            if let denominatorBig {
//                let result = numeratorBig / denominatorBig
//                return result.asInt()
//            } else {
//                return numeratorBig.asInt()
//            }
//        }
//        
//        return nil
//    }
//    
//    var double: Double {
//        if let numeratorNormal {
//            if let denominatorNormal {
//                return Double(numeratorNormal) / Double(denominatorNormal)
//            } else {
//                Double(numeratorNormal)
//            }
//        }
//        
//        if let numeratorBig {
//            if let denominatorBig {
//                let result = numeratorBig / denominatorBig
//                return result.asDouble()
//            } else {
//                return numeratorBig.asDouble()
//            }
//        }
//        
//        fatalError("No double")
//    }
//    
//    var string: String {
//        if let numeratorNormal {
//            if let denominatorNormal {
//                return "\(numeratorNormal) / \(denominatorNormal)"
//            } else {
//                return "\(numeratorNormal)"
//            }
//        }
//        
//        if let numeratorBig {
//            if let denominatorBig {
//                return "\(numeratorBig) / \(denominatorBig)"
//            } else {
//                return "\(numeratorBig)"
//            }
//        }
//        
//        return "Invalid integer"
//    }
//}
//
//extension Number: CustomDebugStringConvertible {
//    var debugDescription: String {
//        return string
//    }
//}
//
//// constants
//
//extension Number {
//    static let pi = Number(0)
//}
//
//// operators
//extension Number: Equatable, Comparable {
//    static func <(lhs: Number, rhs: Number) -> Bool {
//        return true
//    }
//    
//    static func +(lhs: Number, rhs: Number) -> Number {
//        return 0
//    }
//    
//    static func -(lhs: Number, rhs: Number) -> Number {
//        return 0
//    }
//    
//    static func *(lhs: Number, rhs: Number) -> Number {
//        return 0
//    }
//    
//    static func /(lhs: Number, rhs: Number) -> Number {
//        return 0
//    }
//    
//    static func ==(lhs: Number, rhs: Number) -> Number {
//        return 0
//    }
//    
//    static prefix func -(_ n: Number) -> Number {
//        return 0
//    }
//    
//    static func +=(left: inout Number, right: Number) {}
//    static func -=(left: inout Number, right: Number) {}
//    static func *=(left: inout Number, right: Number) {}
//    static func /=(left: inout Number, right: Number) {}
//}

//extension Number {
//    // convert number to nodefield
//    var nodeField: NodeField {
//        NodeField(nodes: [Node(symbol: .simpleValue(self))])
//    }
//}
