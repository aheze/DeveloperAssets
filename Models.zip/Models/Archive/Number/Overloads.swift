//
//  Overloads.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 4/2/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

//func sqrt(_ n: Number) -> Number {
//    return 0
//}
//
//// natural log
//func log(_ n: Number) -> Number {
//    return 0
//}
//
//func log10(_ n: Number) -> Number {
//    return 0
//}
//
//func abs(_ n: Number) -> Number {
//    return 0
//}
//
//func floor(_ n: Number) -> Number {
//    return 0
//}
//
//func ceil(_ n: Number) -> Number {
//    return 0
//}
//
//func round(_ n: Number) -> Number {
//    return 0
//}
//
//func sign(_ n: Number) -> Number {
//    return 0
//}
//
//func fmod(_ n: Number, _ r: Number) -> Number {
//    return 0
//}
//
//func pow(_ base: Number, _ n: Number) -> Number {
//    return 0
//}
//
//func tgamma(_ n: Number) -> Number {
//    return 0
//}
//
//func __sinpi(_ n: Number) -> Number {
//    return 0
//}
//
//func __cospi(_ n: Number) -> Number {
//    return 0
//}
//
//func __tanpi(_ n: Number) -> Number {
//    return 0
//}
//
//func asin(_ n: Number) -> Number {
//    return 0
//}
//
//func acos(_ n: Number) -> Number {
//    return 0
//}
//
//func atan(_ n: Number) -> Number {
//    return 0
//}
//
//func sinh(_ n: Number) -> Number {
//    return 0
//}
//
//func cosh(_ n: Number) -> Number {
//    return 0
//}
//
//func tanh(_ n: Number) -> Number {
//    return 0
//}
//
//func asinh(_ n: Number) -> Number {
//    return 0
//}
//
//func acosh(_ n: Number) -> Number {
//    return 0
//}
//
//func atanh(_ n: Number) -> Number {
//    return 0
//}
