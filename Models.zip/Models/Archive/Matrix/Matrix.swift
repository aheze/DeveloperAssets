//
//  Matrix.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 3/27/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

//enum MatrixError: Error {
//    case matrixMustBeSquare
//    case matrixAugmentMismatchedRowCount
//    case matrixIsSingular
//    case matrixIsNotInvertible
//}
//
//struct Matrix {
//    var rowsCount: Int
//    var colsCount: Int
//
//    // arranged row by row
//    var contents: [Number]
//
//    var rows: [[Number]] {
//        contents.chunked(into: colsCount)
//    }
//
//    var cols: [[Number]] {
//        contents.stridePartition(stride: colsCount)
//    }
//}
//
//// MARK: - Matrix subscript
//
//extension Matrix {
//    // get index inside `contents` for a r and c
//    func contentsIndex(r: Int, c: Int) -> Int {
//        r * colsCount + c
//    }
//
//    subscript(_ r: Int, _ c: Int) -> Number {
//        get {
//            let index = contentsIndex(r: r, c: c)
//            return contents[index]
//        } set {
//            let index = contentsIndex(r: r, c: c)
//            contents[index] = newValue
//        }
//    }
//}
//
//extension Matrix {
//    static func zero(n: Int) -> Matrix {
//        return Matrix(
//            rowsCount: n,
//            colsCount: n,
//            contents: Array(repeating: Number(0), count: n * n)
//        )
//    }
//
//    static func diagonal(n: Int, values: [Number]) -> Matrix {
//        var matrix = Matrix.zero(n: n)
//        for index in 0 ..< n {
//            let contentsIndex = matrix.contentsIndex(r: index, c: index)
//            matrix.contents[contentsIndex] = values[index]
//        }
//        return matrix
//    }
//
//    static func identity(n: Int) -> Matrix {
//        return diagonal(n: n, values: Array(repeating: Number(1), count: n))
//    }
//}
//
//extension Matrix: CustomDebugStringConvertible {
//    var debugDescription: String {
//        let header = "\n⎡Matrix \(rowsCount)x\(colsCount)⎤\n"
//
//        let content = rows.dropLast().map {
//            let row = "⎢\($0.map { "\($0)" }.joined(separator: " "))⎥"
//            return row
//        }.joined(separator: "\n")
//
//        let last = rows.last!
//        let lastRow = "\n⎣\(last.map { "\($0)" }.joined(separator: " "))⎦"
//
//        return header + content + lastRow
//    }
//}
