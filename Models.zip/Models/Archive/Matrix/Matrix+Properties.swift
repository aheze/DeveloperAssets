//
//  Matrix+Properties.swift
//  MetalMathTest
//
//  Created by Andrew Zheng (github.com/aheze) on 4/1/24.
//  Copyright © 2024 Andrew Zheng. All rights reserved.
//

import Foundation

//extension Matrix {
//    var isSquare: Bool {
//        rowsCount == colsCount
//    }
//
//    func computeDeterminant() throws -> Number {
//        guard isSquare else {
//            throw MatrixError.matrixMustBeSquare
//        }
//
//        let (swaps, scale, matrix) = reduce(into: .ref)
//        
//        print("det: matrix; \(matrix)")
//
//        // each swap scales the result by -1
//        var diagonalProduct: Number = swaps % 2 == 0 ? 1 : -1
//        for i in 0 ..< matrix.colsCount {
//            diagonalProduct = diagonalProduct * matrix[i, i]
//        }
//        return diagonalProduct * scale
//    }
//
//    func computeTrace() throws -> Number {
//        guard isSquare else {
//            throw MatrixError.matrixMustBeSquare
//        }
//
//        let sum = FunctionLibrary.kahanSum(range: 0 ..< colsCount) { i in
//            self[i, i]
//        }
//
//        return sum
//    }
//}
