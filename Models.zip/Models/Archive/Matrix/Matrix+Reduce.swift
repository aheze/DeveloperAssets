////
////  Matrix+Reduce.swift
////  MetalMathTest
////
////  Created by Andrew Zheng (github.com/aheze) on 4/1/24.
////  Copyright © 2024 Andrew Zheng. All rights reserved.
////
//
//import Foundation
//
//extension Matrix {
//    enum EchelonForm {
//        case ref
//        case rref
//    }
//
//    func computeREF() -> Matrix {
//        let (_, _, matrix) = reduce(into: .ref)
//        return matrix
//    }
//
//    func computeRREF() -> Matrix {
//        let (_, _, matrix) = reduce(into: .rref)
//        return matrix
//    }
//
//    func reduce(into form: EchelonForm) -> (swaps: Int, scale: Number, Matrix) {
//        var matrix = self
//
//        var swaps = 0
//        var scale = Number(1)
//
//        // from https://rosettacode.org/wiki/Reduced_row_echelon_form#Swift
//        // the lead position
//        var lead = 0
//        for r in 0 ..< rowsCount {
//            if colsCount <= lead { break }
//
//            var i = r
//            while matrix[i, lead] == 0 {
//                i += 1
//                if i == rowsCount {
//                    i = r
//                    lead += 1
//                    if colsCount == lead {
//                        lead -= 1
//                        break
//                    }
//                }
//            }
//
//            if i != r {
//                for j in 0 ..< colsCount {
//                    let temp = matrix[r, j]
//                    matrix[r, j] = matrix[i, j]
//                    matrix[i, j] = temp
//                }
//                swaps += 1
//            }
//
//            let div = matrix[r, lead]
//
//            if form == .rref, div != 0 {
//                scale = scale * div
//                for j in 0 ..< colsCount {
//                    matrix[r, j] /= div
//
////                    if abs(matrix[r, j]) < 0.0001 {
////                        matrix[r, j] = 0
////                    }
//                }
//            }
//
//            if form == .rref {
//                for j in 0 ..< rowsCount where j != r {
//                    // no need to divide by `matrix[r, lead]` because it's just 1
//                    let coefficient = matrix[j, lead]
//
//                    for c in 0 ..< colsCount {
//                        matrix[j, c] -= (coefficient * matrix[r, c])
//
////                        if abs(matrix[j, c]) < 0.0001 {
////                            matrix[j, c] = 0
////                        }
//                    }
//                }
//            } else {
//                // loop over other rows to make them 0
//                for j in 0 ..< rowsCount where j != r && j > r {
//                    // the current value. Need to make this 0
//                    let current = matrix[j, lead]
//
//                    // happens when `lead` points to the last column,
//                    // where `matrix[j, lead]` is 0
//                    if current == 0 {
//                        continue
//                    } else {
//                        // e.g. R3 = R3 - 0.25R2 -> 0.25 is the coefficient
//                        let coefficient = current / matrix[r, lead]
//
//                        for c in 0 ..< colsCount {
//                            matrix[j, c] = matrix[j, c] - (coefficient * matrix[r, c])
//
////                            if abs(matrix[j, c]) < 0.0001 {
////                                matrix[j, c] = 0
////                            }
//                        }
//                    }
//                }
//            }
//
//            lead += 1
//        }
//
//        return (swaps, scale, matrix)
//    }
//}
