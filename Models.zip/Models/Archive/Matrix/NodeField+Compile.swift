////
////  NodeField+Compile.swift
////  MetalMathTest
////
////  Created by Andrew Zheng (github.com/aheze) on 3/23/24.
////  Copyright © 2024 Andrew Zheng. All rights reserved.
////
//
//import SwiftUI
//
////struct EvaluationContext {
////    var trigonometryMode = TrigonometryMode.radian
////
////    // id to NodeField
////    var substitutions = [String: NodeField]()
////
////    enum TrigonometryMode {
////        case radian
////        case degree
////    }
////}
//
//struct CompileContext {
// 
//}
//
//struct CompileResult {
//    var string = ""
//}
//
//extension NodeField {
//    func compile(context: CompileContext = CompileContext()) -> CompileResult {
//        var compileResult = CompileResult()
//        for node in nodes {
//            
//            
//            
//            for field in node.fields {
//                let result = field.compile(context: context)
//                
//                
//                
//            }
//        }
//        return compileResult
//    }
//}
