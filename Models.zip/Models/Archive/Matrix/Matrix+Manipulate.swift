////
////  Matrix+Manipulate.swift
////  MetalMathTest
////
////  Created by Andrew Zheng (github.com/aheze) on 4/1/24.
////  Copyright © 2024 Andrew Zheng. All rights reserved.
////
//
//import Foundation
//
//extension Matrix {
//    func transpose() -> Matrix {
//        var transpose = Matrix(
//            rowsCount: colsCount,
//            colsCount: rowsCount,
//            contents: Array(repeating: Number(0), count: contents.count)
//        )
//
//        for (i, r) in rows.enumerated() {
//            for (j, e) in r.enumerated() {
//                transpose[j, i] = e
//            }
//        }
//        return transpose
//    }
//
//    func augment(by b: Matrix) throws -> Matrix {
//        guard self.rowsCount == b.rowsCount else {
//            throw MatrixError.matrixAugmentMismatchedRowCount
//        }
//
//        let aRows = self.rows
//        let bRows = b.rows
//
//        let zipped = zip(aRows, bRows)
//        let contents = zipped.map { $0.0 + $0.1 }.flatMap { $0 }
//        let matrix = Matrix(rowsCount: rowsCount, colsCount: colsCount + b.colsCount, contents: contents)
//        return matrix
//    }
//
//    func inverse() throws -> Matrix {
//        let determinant = try computeDeterminant()
//
//        if determinant == 0 {
//            // matrix is non-invertible
//            throw MatrixError.matrixIsSingular
//        }
//
//        let identity = Matrix.identity(n: rowsCount)
//        let augmented = try augment(by: identity)
//        let rref = augmented.computeRREF()
//
//        return rref.splice(startR: 0, startC: rowsCount, rowsCount: rowsCount, colsCount: rowsCount)
//    }
//
//    func splice(startR: Int = 0, startC: Int = 0, rowsCount: Int, colsCount: Int) -> Matrix {
//        var matrix = Matrix(
//            rowsCount: rowsCount,
//            colsCount: colsCount,
//            contents: Array(repeating: 0, count: rowsCount * colsCount)
//        )
//        
//        for r in 0 ..< rowsCount {
//            for c in 0 ..< colsCount {
//                matrix[r, c] = self[r + startR, c + startC]
//            }
//        }
//
//        return matrix
//    }
//}
